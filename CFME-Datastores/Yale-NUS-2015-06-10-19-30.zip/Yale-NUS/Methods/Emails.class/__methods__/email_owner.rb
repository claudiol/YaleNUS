###################################
#
# CloudForms Automate Method: Email_Owner
#
# This method is used to Email_Owner AWS Services
#
###################################
#
# Method for logging
begin
  @method = 'Email_Owner'
  $evm.log("info", "#{@method} - EVM Automate Method Started")

  # Turn of verbose logging
  @debug = true

  require "json"

  ###################################
  # Method: dumpRoot
  #
  ###################################
  def dumpRoot
    $evm.log("info", "#{@method} - Root:<$evm.root> Begin Attributes")
    $evm.root.attributes.sort.each { |k, v| $evm.log("info", "#{@method} - Root:<$evm.root> Attributes - #{k}: #{v}")}
    $evm.log("info", "#{@method} - Root:<$evm.root> End Attributes")
    $evm.log("info", "")
  end

  dumpRoot

  vm = $evm.root['vm']

  payload = nil
  payload ||= $evm.object['payload']
  $evm.log("info", "#{@method} - ==================== payload: #{payload.inspect}") if @debug

  @data = JSON.load(payload)
  $evm.log("info", "#{@method} - ==================== data: #{@data.inspect}") if @debug

  type = nil
  type ||= @data['type']
  $evm.log("info", "#{@method} - ==================== type: #{type.inspect}") if @debug

  $evm.log("info", "#{@method} - ==================== VM: #{vm.inspect}") if @debug

  
  ####################
  from = nil
  from ||= $evm.root['from_email'] || 'admin@cloudforms.iad.salab.redhat.com'
  evm_owner_id = vm.attributes['evm_owner_id']
  owner = nil
  owner = $evm.vmdb('user', evm_owner_id) unless evm_owner_id.nil?
  $evm.log("info", "#{@method} - VM Owner: #{owner.inspect}") if @debug
  @to = nil
  @to = owner.email unless owner.nil?
  
  if @to.nil?
    $evm.log(:info, "Sending email to: #{$evm.root['user'].email}")
    @to = $evm.root['user'].email
  end
  
  @signature = nil
  @signature ||= $evm.object['signature'] || "Your Virtualization Team"

  def email_info()
    @body += "-------------------------------- <br>"
    @body += "Forward the message below to <br>"
    @body += "#{@to}"
    @body += "<br>-------------------------------- <br>"
    @body += "<br>"
    @body += "-------------------------------- <br>"
    @body += " #{@data['service_name']} Info<br>"
    @body += "-------------------------------- "
  end

  def email_footer()
    @body += "<br><br> If you have any issues with your new #{@data['service_name']} please contact Support."
    @body += "<br><br> Thank you,<br>"
    @body += "#{@signature}"
  end

  case type

    ##################################################################################################################
    when "test"
      $evm.log("info", "#{@method} - ==================== vm: #{vm.inspect}") if @debug
    ##################################################################################################################

    ##################################################################################################################
    when "create_ebs_volume"
      $evm.log("info", "#{@method} - ==================== Running: #{type.inspect}") if @debug
      subject = "Your #{@data['service_name']} request has been #{@data['action']}: #{@data['vol_name']}"
      $evm.log("info", "#{@method} - ==================== subject: #{subject.inspect}") if @debug
      @body = "Hello, "
      @body += "This email is being sent by EVM to inform you of the provisioning of a new #{@data['service_name']}.<br>"
      @body += "This new #{@data['service_name']} requires verification in the Amazon EC2 console.<br>"
      @body += "Once that has been completed, use this message to inform the "
      @body += "requester that their new #{@data['service_name']} is ready.<br><br>"
      email_info()
      # Send custom info
      @body += "<br><b>Action:</b> #{@data['action']}"
      @body += "<br><b>Volume Info</b> #{@data['vol_name']}"
      email_footer()
      $evm.log("info", "#{@method} - ==================== body: #{@body.inspect}") if @debug
    ##################################################################################################################

    ##################################################################################################################
    when "create_attach_ebs_volume"
      $evm.log("info", "#{@method} - ==================== Running: #{type.inspect}") if @debug
      subject = "Your #{@data['service_name']} request has been #{@data['action']} - #{@data['vm_name']}: #{@data['vol_name']}"
      $evm.log("info", "#{@method} - ==================== subject: #{subject.inspect}") if @debug
      @body = "Hello, "
      @body += "This email is being sent by EVM to inform you of the provisioning of a new #{@data['service_name']}.<br>"
      @body += "This new #{@data['service_name']} requires verification in the Amazon EC2 console.<br>"
      @body += "Once that has been completed, use this message to inform the "
      @body += "requester that their new #{@data['service_name']} is ready.<br><br>"
      email_info()
      # Send custom info
      @body += "<br><b>Action:</b> #{@data['action']}"
      @body += "<br><b>VM Name:</b> #{@data['vm_name']}"
      @body += "<br><b>Volume Info</b> #{@data['vol_name']}"
      @body += "<br><b>Attached to:</b> #{@data['selected_device_name']}"
      email_footer()
      $evm.log("info", "#{@method} - ==================== body: #{@body.inspect}") if @debug
    ##################################################################################################################

    ##################################################################################################################
    when "attach_ebs_volume"
      $evm.log("info", "#{@method} - ==================== Running: #{type.inspect}") if @debug
      subject = "Your #{@data['service_name']} request has been #{@data['action']} - #{@data['vm_name']}: #{@data['instance_id']}"
      $evm.log("info", "#{@method} - ==================== subject: #{subject.inspect}") if @debug
      @body = "Hello, "
      @body += "This email is being sent by EVM to inform you of the #{@data['service_name']} has been attached to #{@data['vm_name']}.<br>"
      @body += "This new #{@data['service_name']} requires verification in the Amazon EC2 console.<br>"
      @body += "Once that has been completed, use this message to inform the "
      @body += "requester that their new #{@data['service_name']} is ready.<br><br>"
      email_info()
      # Send custom info
      @body += "<br><b>Action:</b> #{@data['action']}"
      @body += "<br><b>VM Name:</b> #{@data['vm_name']}"
      @body += "<br><b>Instance ID:</b> #{@data['instance_id']}"
      @body += "<br><b>Attached to:</b> #{@data['selected_device_name']}"
      email_footer()
      $evm.log("info", "#{@method} - ==================== body: #{@body.inspect}") if @debug
    ##################################################################################################################

    ##################################################################################################################
    when "delete_ebs_volume"
      $evm.log("info", "#{@method} - ==================== Running: #{type.inspect}") if @debug
      subject = "Your #{@data['service_name']} request has been #{@data['action']} - #{@data['vm_name']}: #{@data['vol_name']}"
      $evm.log("info", "#{@method} - ==================== subject: #{subject.inspect}") if @debug
      @body = "Hello, "
      @body += "<br>This email is being sent by EVM to inform you of the #{@data['vol_name']} has been #{@data['action']}.<br>"
      email_info()
      # Send custom info
      @body += "<br><b>Action:</b> #{@data['action']}"
      @body += "<br><b>Volume Info</b> #{@data['vol_name']}"
      email_footer()
      $evm.log("info", "#{@method} - ==================== body: #{@body.inspect}") if @debug
    ##################################################################################################################

    ##################################################################################################################
    when "detach_ebs_volume"
      $evm.log("info", "#{@method} - ==================== Running: #{type.inspect}") if @debug
      subject = "Your #{@data['service_name']} request has been #{@data['action']} - #{@data['vm_name']}: #{@data['vol_name']}"
      $evm.log("info", "#{@method} - ==================== subject: #{subject.inspect}") if @debug
      # Call the header
      @body = "Hello, "
      @body += "<br>This email is being sent by EVM to inform you of the #{@data['vol_name']} has been #{@data['action']} from #{@data['vm_name']}<br>"
      email_info()
      # Send custom info
      @body += "<br><b>Action:</b> #{@data['action']}"
      @body += "<br><b>VM Name:</b> #{@data['vm_name']}"
      @body += "<br><b>Volume Info</b> #{@data['vol_name']}"
      email_footer()
      $evm.log("info", "#{@method} - ==================== body: #{@body.inspect}") if @debug
    ##################################################################################################################

    ##################################################################################################################
    when "create_attach_elb"
      $evm.log("info", "#{@method} - ==================== Running: #{type.inspect}") if @debug
      subject = "Your #{@data['service_name']} request has #{@data['action']} - #{@data['vm_name']}: #{@data['elb_name']}"
      $evm.log("info", "#{@method} - ==================== subject: #{subject.inspect}") if @debug
      @body = "Hello, "
      @body += "<br>This email is being sent by EVM to inform you of the provisioning of a new #{@data['service_name']}.<br>"
      @body += "This new #{@data['service_name']} requires verification in the Amazon EC2 console.<br>"
      @body += "Once that has been completed, use this message to inform the "
      @body += "requester that their new #{@data['service_name']} is ready.<br><br>"
      email_info()
      # Send custom info
      @body += "<br><b>Action:</b> #{@data['action']}"
      @body += "<br><b>Amazon ELB Name  :</b> #{@data['elb_name']}"
      @body += "<br><b>ELB Amazon Region:</b> #{@data['region']}"
      @body += "<br><b>ELB Amazon Availability Zone:</b> #{@data['availability_zone']}"
      email_footer()
      $evm.log("info", "#{@method} - ==================== body: #{@body.inspect}") if @debug
    #############################################################################################################

  end

  $evm.log(:info, "Sending email to #{@to} from #{from} subject: #{subject}")
  $evm.execute(:send_email, @to, from, subject, @body)

  $evm.log("info", "#{@method} - ================================= EVM Automate Method Ended")

  #
  # Exit method
  #
  $evm.log("info", "#{@method} - EVM Automate Method Ended")
  exit MIQ_OK

    #
    # Set Ruby rescue behavior
    #
rescue => err
  $evm.log("error", "#{@method} - [#{err}]\n#{err.backtrace.join("\n")}")
  exit MIQ_STOP
end
