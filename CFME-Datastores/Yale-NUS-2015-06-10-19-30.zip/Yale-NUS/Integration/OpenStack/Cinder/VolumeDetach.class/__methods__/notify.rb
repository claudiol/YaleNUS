begin 
  vars = Hash.new
  vars[:type] = "detach_cinder_volume"
  vars[:action] = "Detached"
  vars[:service_name] = "OpenStack Cinder"
  vars[:vol_name] = vol.name
  vars[:vm_name] = vm['name']

  require 'json'
  require 'uri'
  args = "payload=#{vars.to_json}"
  args = URI.escape(args)
  $evm.log("info", "============== vars: #{vars.inspect}")
  $evm.log("info", "============== args: #{args.inspect}")
  $evm.instantiate("/Yale/Methods/Emails/Email_OpenStack_Owner?#{args}")
end
