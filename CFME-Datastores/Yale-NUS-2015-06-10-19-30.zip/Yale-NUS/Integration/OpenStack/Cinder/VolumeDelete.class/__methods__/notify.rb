begin
    
  vars = Hash.new
  vars[:type] = "delete_cinder_volume"
  vars[:action] = "Deleted"
  vars[:service_name] = "OpenStack Cinder"
  vars[:vol_name] = volume_name

  require 'json'
  require 'uri'
  args = "payload=#{vars.to_json}"
  args = URI.escape(args)
  $evm.log("info", "============== vars: #{vars.inspect}")
  $evm.log("info", "============== args: #{args.inspect}")
  $evm.instantiate("/Yale/Methods/Emails/Email_OpenStack_Owner?#{args}")
end
