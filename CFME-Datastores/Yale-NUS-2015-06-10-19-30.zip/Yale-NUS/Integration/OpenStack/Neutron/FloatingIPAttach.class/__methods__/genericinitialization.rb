######
#
# In Generic Initialization, we don't assume that we have what we need in the current
# context, so we just fetch from $evm.root
#
######

# We look into $evm.root[ROOT_EVM_KEY_VM_ID] when we don't have a vm_id value in the state machine.
ROOT_EVM_KEY_VM_ID = "/Integration/OpenStack/Neutron/FloatingIPAttach/vm_id"

# We look into $evm.root[ROOT_EVM_KEY_FLOATING_IP] when we don't have a floating_ip_pool_name value in the state machine.
ROOT_EVM_KEY_FLOATING_POOL_NAME = "/Integration/OpenStack/Neutron/FloatingIPAttach/floating_pool_name"

# Get the VM ID from global context.
vm_id = $evm.root[ROOT_EVM_KEY_VM_ID]
floating_ip_pool_name = $evm.root[ROOT_EVM_KEY_FLOATING_POOL_NAME]

# Pull the VM and it's EMS from the VMDB.
vm = $evm.vmdb(:vm).find(vm_id)
ems = vm.ext_management_system

# Populate the instance attributes for the next step.
$evm.object["vm_id"] = vm_id
$evm.object["floating_ip_pool_name"] = floating_ip_pool_name
$evm.object["os_authentication_userid"] = ems.authentication_userid
$evm.object["os_authentication_password"] = ems.authentication_password
$evm.object["os_authentication_url"] = "http://#{ ems.hostname }:#{ ems.port }/v2.0/tokens"
