###################################
#
# CloudForms Automate Method: create_ebs_volume
#
# This method is used to create a AWS EC2 EBS Volume
#
###################################
# Method for logging
def log(level, message)
  @method = 'create_ebs_volume'
  $evm.log(level, "#{@method} - #{message}")
end

log(:info, "CloudForms Automate Method Started")

require 'aws-sdk'

# Get provisioning object

begin

  access_key_id = nil
  secret_access_key = nil

  # Get the Amazon ems ref
  ems = $evm.vmdb(:ems_amazon).first
  
  # Addiong the user info and downcasing it
  user = $evm.root['user'].userid.downcase

  #AWS doesn't like underscores, dashes or spaces so strip for group
  user_group = $evm.root['user'].ldap_group.downcase.gsub(/[\W+]|[_]/,'')

  # Get the Amazon authentication credentials...
  access_key_id = ems.authentication_userid       # $evm.object['access_key_id']
  secret_access_key = ems.authentication_password # $evm.object.decrypt('secret_access_key')

  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  region = $evm.object['dialog_aws_region']

  availability_zone = $evm.object['dialog_availability_zone']

  # Get volume name from the dialog
  vol_name = $evm.object['dialog_aws_ebs_volume_name']

  # Get the EBS size
  ebs_size = $evm.object['dialog_ebs_size'].to_i

  log(:info, " +++++++++++++++++ EBS Size : #{ebs_size.to_i} ++++++++++++++")


  # Start Here


  log(:info, "+++++++++++++++ Selected Region: #{region} +++++++++++++++++++++++++")

  #Set Availability Zone

  log(:info, "+++++++++++++++ Selected Availability Zone : #{availability_zone} ++++++++++++++++++")

  log(:info, "+++++++++++++++ User Name : #{user} ++++++++++++++++++++++")
  log(:info, "+++++++++++++++ Group Name : #{user_group} +++++++++++++++++++")

  ec2 = AWS::EC2.new( :region => region  )


  volume = ec2.volumes.create(:size => ebs_size,
                              :availability_zone => availability_zone)

  # Now Tag the newly created volume from the username/groupid and volume name
  ec2.volumes["#{volume.id}"].tags["userid"] = "#{user}"
  ec2.volumes["#{volume.id}"].tags["usergroup"] = "#{user_group}"
  ec2.volumes["#{volume.id}"].tags["Name"] = "#{vol_name}"

  ############
  # Exit method
  #
  log(:info, "CloudForms Automate Method Ended")
  exit MIQ_OK
end

