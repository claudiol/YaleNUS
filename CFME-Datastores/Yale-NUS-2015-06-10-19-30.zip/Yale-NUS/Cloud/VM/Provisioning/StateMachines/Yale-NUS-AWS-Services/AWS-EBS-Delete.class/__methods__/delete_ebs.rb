###################################
#
# CloudForms Automate Method: delete_ebs_volume
#
# This method is used to delete a AWS EC2 EBS Volume
#
###################################
# Method for logging
def log(level, message)
  @method = 'delete_ebs_volume'
  $evm.log(level, "#{@method} - #{message}")
end

def dumpRoot
  $evm.log("info", "#{@method} - Root:<$evm.root> Begin Attributes")
  $evm.root.attributes.sort.each { |k, v| $evm.log("info", "#{@method} - Root:<$evm.root> Attributes - #{k}: #{v}")}
  $evm.log("info", "#{@method} - Root:<$evm.root> End Attributes")
  $evm.log("info", "")
end

# dump root object attributes
dumpRoot

log(:info, "CloudForms Automate Method Started")

require 'aws-sdk'

# Get provisioning object
dialog_field = $evm.object

begin

  access_key_id = nil
  secret_access_key = nil

  # Addiong the user info and downcasing it
  user = $evm.root['user'].userid.downcase

  #AWS doesn't like underscores, dashes or spaces so strip for group
  user_group = $evm.root['user'].ldap_group.downcase.gsub(/[\W+]|[_]/,'')

  # Get the Amazon ems ref
  ems = $evm.vmdb(:ems_amazon).first
  
  # Get the Amazon authentication credentials...
  access_key_id = ems.authentication_userid       # $evm.object['access_key_id']
  secret_access_key = ems.authentication_password # $evm.object.decrypt('secret_access_key')

  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  vol_list_region = $evm.object['dialog_aws_ebs_volume_list']
  log(:info, "++++++++++++++++ Vol List Region : #{vol_list_region} +++++++++++++++++++")
  vol_list_region = vol_list_region.split("|").each {|t| t.strip!}

  region = vol_list_region[1]


  selected_ebs_volume = vol_list_region[0]
  log(:info, "++++++++++++ Selected EBS Volume : #{selected_ebs_volume} ++++++++++++++++++++")

  # Start Here

  log(:info, "++++++++++++++++++ Region : #{region} +++++++++++++++++++")

  ec2 = AWS::EC2.new( :region => region  )

  volume = ec2.volumes[selected_ebs_volume]
    volume.attachments.each do |attachment|
        attachment.delete(:force => true)
      end
    sleep 1 until volume.status == :available
    volume.delete

  ############
  # Exit method
  #
  log(:info, "CloudForms Automate Method Ended")
  exit MIQ_OK
end
