#
# Description: This method is used to Customize the Openstack Provisioning Request
#

###### TRACERS ######
# Method for logging
def log(level, message)
  @method = 'openstack_CustomizeRequest'
  $evm.log(level, "#{@method} - #{message}")
end

def info(message)
  log(:info, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

info("openstack_CustomizeRequest Automate Method Started")

require 'json'

# Get provisioning object
prov = $evm.root["miq_provision"]

ws_values = prov.get_option(:ws_values)

# Check that we have :ws_values
unless ws_values.nil?
  
  # copy everything blind at first, customize later
  ws_values.each { |k, v| prov.set_option(k, v) }
  
  # Get the VM size
  flavor_id = ws_values[:instance_type]
  flavor = $evm.vmdb(:flavor).find_by_id(flavor_id)

  # Get number of VMs
  no_of_vms = prov.get_option(:dialog_vm_qty)

  # Set up the VM name
  vm_name = "[#{ prov.get_option(:dialog_app_name) }] #{ prov.get_option(:dialog_vm_name) }"

  # Get customization template for cloud-init
  customization_template = $evm.vmdb(:CustomizationTemplate).find(ws_values[:customization_template_id])
  
  prov.set_option(:vm_tags, ws_values[:project])
  prov.set_option(:instance_type, [flavor.id, flavor.name])

  prov.set_option(:vm_tags, JSON.parse(ws_values[:vm_tags]))
  prov.set_option(:placement_auto, JSON.parse(ws_values[:placement_auto]))
  prov.set_option(:placement_availability_zone, JSON.parse(ws_values[:placement_availability_zone]))
  prov.set_option(:cloud_tenant, JSON.parse(ws_values[:cloud_tenant]))
  prov.set_option(:cloud_network, JSON.parse(ws_values[:cloud_network]))
  prov.set_option(:security_groups, JSON.parse(ws_values[:security_groups]))
  prov.set_customization_template(customization_template) rescue nil
  
  # push the dialog options in as well
end

dump_attributes(prov)

info("Provisioning ID:<#{prov.id}> Provision Request ID:<#{prov.miq_provision_request.id}> Provision Type: <#{prov.provision_type}>")
