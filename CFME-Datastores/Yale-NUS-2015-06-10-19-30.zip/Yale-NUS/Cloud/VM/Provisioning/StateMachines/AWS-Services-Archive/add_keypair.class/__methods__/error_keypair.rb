#
#            Automate Method
#
# Method for logging
def log(level, message)
  @method = 'error_keypair'
  $evm.log(level, "#{@method} - #{message}")
end
#
log(:info, "AWS Keypair ERROR - Automate Method Started")
#
#            Method Code Goes here
#

# Get the service provision object
prov    = $evm.root['service_template_provision_task']

# Get the current error ...
current_error = $evm.root['current_error']

###################################
#
# Update Status for on_error
#
###################################
$evm.object['ae_result'] = 'error'
prov.message = current_error
$evm.object['ae_reason'] = current_error

log(:info, "========== AWS ERROR ATTRIBUTE LOG =================================")
log(:info, "Listing ROOT Attributes:")
$evm.root.attributes.sort.each { |k, v| log(:info, "\t#{k}: #{v}")}
log(:info, "=========== AWS ERROR ATTRIBUTE LOG ================================")

unless prov.nil?
  log(:info, "========== AWS ERROR ATTRIBUTE LOG =================================")
  log(:info, "Listing PROV OBJECT Attributes:")
  prov.attributes.sort.each { |k, v| log(:info, "\t#{k}: #{v}")}
  log(:info, "=========== AWS ERROR ATTRIBUTE LOG ================================")
end
#
#
#
log(:info, "AWS Keypair ERROR - Automate Method Ended")
exit MIQ_OK
