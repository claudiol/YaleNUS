###################################
#
# CloudForms Automate Method: ebs_device_list
#
# This method is used to attach an EBS using the allowed device list
#
###################################
# Method for logging
def log(level, message)
  @method = 'ebs_device_list'
  $evm.log(level, "#{@method} - #{message}")
end

def dumpRoot
  $evm.log("info", "#{@method} - Root:<$evm.root> Begin Attributes")
  $evm.root.attributes.sort.each { |k, v| $evm.log("info", "#{@method} - Root:<$evm.root> Attributes - #{k}: #{v}")}
  $evm.log("info", "#{@method} - Root:<$evm.root> End Attributes")
  $evm.log("info", "")
end

# dump root object attributes
dumpRoot

log(:info, "CloudForms Automate Method Started")

require 'aws-sdk'
dialog_field = $evm.object

# Get provisioning object

begin

  vm = $evm.root['vm']

  ems = vm.ext_management_system

  region = ems.provider_region
  
  # log(:info, "EMS Object : #{ems.inspect}")
    
  # Get the Amazon authentication credentials...
  access_key_id ||= ems.authentication_userid
  secret_access_key = ems.authentication_password

  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  # Dynamic list to add values to the dialog dynamic list ...
  list = {}
  in_use_devices = []
  allowed_ebs_devices = []

  # Count of regions ...
  count = 0

  # Save first entry and make it the default region
  first = nil

  # Start Here

  allowed_ebs_devices = $evm.object['allowed_device_list']
  allowed_ebs_devices = allowed_ebs_devices.split(",").each {|t| t.strip!}


  # Create the basic EC2 object

  ec2 = AWS::EC2.new( :region => region )

  # Set the instance from current instance
  i = ec2.instances["#{vm.uid_ems}"]
  
  log(:info,"INSTANCE: #{i.inspect} UID: #{vm.uid_ems}")

  # Find all instance block devices and push them to an array taking out any numbers
  i.block_devices.each do |b|
    in_use_devices.push(b[:device_name].gsub(/[0-9]/,''))
  end

  # Remove any in use devices from the list of allowed devices and set to a new array
  allowed_ebs_devices = allowed_ebs_devices - in_use_devices

  # For each available device from allowed devices put into the list
  allowed_ebs_devices.each do |d|
    count += 1
    if count == 1
      first = "#{d}"
    end
    list["#{d}"]  = d
  end

  list[""] = ""
  
  log(:info, "LIST: #{list.inspect} ")

  # sort_by: value / description / none
  $evm.object["sort_by"] = "description"
  # sort_order: ascending / descending
  $evm.object["sort_order"] = "ascending"
  # data_type: string / integer
  $evm.object["data_type"] = "string"
  # required: true / false
  $evm.object["required"] = "true"
  # Add list to dialog dynamic list ...
  $evm.object["values"] = list


  # Make the first entry the default value
  $evm.object["default_value"] = first


  ############
  # Exit method
  #
  log(:info, "CloudForms Automate Method Ended")
  exit MIQ_OK
end
