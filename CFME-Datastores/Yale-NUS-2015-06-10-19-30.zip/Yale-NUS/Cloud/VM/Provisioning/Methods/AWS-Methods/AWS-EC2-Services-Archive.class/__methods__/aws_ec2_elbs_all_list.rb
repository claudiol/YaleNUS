#
#            Automate Method
#
$evm.log("info", "===== AWS List ELBs ==== Automate Method Started")
#
# Method for logging
def log(level, message)
  @method = 'AWSELB'
  $evm.log(level, "#{@method} - #{message}")
end
#            Method Code Goes here
#
# Load the aws-sdk
require "aws-sdk"


begin

  #####RBAC sample, setting the filter mode

  this_user = $evm.root['user'].userid.downcase
  log(:info, "this_user : #{this_user.inspect}")
  #AWS doesn't like underscores, dashes or spaces so strip
  this_user_group = $evm.root['user'].ldap_group.downcase.gsub(/[\W+]|[_]/,'')
  log(:info, "this_user_group (cleaned of underscores): #{this_user_group.inspect}")


  filter_user = 'none' # values user, group, none

  if this_user_group  == 'evmgroupsuperadministrator' #remember that the naming removes any underscores, always lower
    filter_user = 'none'
  elsif this_user_group.nil?
    filter_user = 'user'
  elsif this_user_group == 'cloudforms'  #remember to tag all lower case, naming stripped with the REGEX
    filter_user = 'user'
  else
    filter_user = 'group'
  end

  # dialog_field = $evm.object
  access_key_id = nil
  secret_access_key = nil

  # Get the Amazon authentication credentials...
  ems = $evm.vmdb(:ems_amazon).first
  
  if ems.nil?
    # Get the values from the schema ...
    access_key_id ||= $evm.object['access_key_id']
    secret_access_key = $evm.object.decrypt('secret_access_key')
  else
    access_key_id ||= ems.authentication_userid
    secret_access_key = ems.authentication_password
  end
  
  allowed_regions = $evm.object['allowed_regions']
  allowed_regions = allowed_regions.split(",").each {|t| t.strip!}


  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  log(:info, "+++++++++++++++++++ Dump of Allowed Regions : #{allowed_regions} +++++++++++++++++++++++")

# Create some local variables ...

# Dynamic list to add values to the dialog dynamic list ...
  list = {}

  # Count of regions ...
  count = 0

  # Save first entry and make it the default region
  first = nil


  allowed_regions.each do |r|
    elb_instance = AWS::ELB.new( :region => r )

    elbs = elb_instance.load_balancers
    log(:info, "ELB : #{elbs.inspect}")

    # Go through all regions returned from EC2 and add them to list
    elbs.each do |k|
      count += 1
      if count == 1
        first = k.name
      end

      if filter_user =='user'
        if k.name.downcase.include? this_user
          $evm.log("info", "ELBS (added) : #{k.name} ")
          list[k.name]  = "#{k.name}"
        else
          $evm.log("info", "ELBS (skipped, not user): #{k.name} ")
        end
      elsif filter_user =='group'
        if k.name.downcase.include? this_user_group
          $evm.log("info", "ELBS (added) : #{k.name} ")
          list[k.name]  = "#{k.name}"
        else
          $evm.log("info", "ELBS (skipped, not group): #{k.name} ")
        end
      else #should only fall through for Admin - group EvmGroup-super_administrator
        $evm.log("info", "ELBS (added) : #{k.name} ")
        list[k.name]  = "#{k.name}"
      end
    end
  end

  list[""] = ""

  $evm.log("info", "LIST: #{list.inspect} ")

  # sort_by: value / description / none
  $evm.object["sort_by"] = "description"
  # sort_order: ascending / descending
  $evm.object["sort_order"] = "ascending"
  # data_type: string / integer
  $evm.object["data_type"] = "string"
  # required: true / false
  $evm.object["required"] = "true"
  # Add list to dialog dynamic list ...
  $evm.object["values"] = list


  # Make the first entry the default value
  $evm.object["default_value"] = first


  $evm.log("info", "Dialog Inspect: #{$evm.object.inspect}")

  $evm.log("info", "====== RETRIEVE AMAZON ELASTIC LOAD BALANCERS =====  Automate Method Ended")
  exit MIQ_OK

rescue => exception
$evm.log("info", "====== EXCEPTION IN RETRIEVE AMAZON ELASTIC LOAD BALANCERS =====")
$evm.log("info", exception.message)
end
