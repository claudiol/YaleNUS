#
# Description: Populate a dynamic drop down list with available AWS regions
#

$evm.log("info", "populateAwsProviders Automate Method Started")

droplist = $evm.object

droplist["data_type"] = "String"
droplist["required"] = "true"

# Retrieve AWS ext_management_system
aws_ems = $evm.vmdb(:ems_amazon).all
$evm.log("info", "Fetched all Amazon EMS: #{ aws_ems }")

# Create droplist values
option_hash = {}
aws_ems.each { |ems|
  key = ems.id.to_s
  value = "#{ ems.name } (#{ ems.provider_region })"
  $evm.log("info", "Adding '#{ key }':'#{ value }' to droplist values")
  option_hash[key] = value
}
$evm.log("info", "Generated droplist options: #{ option_hash }")
droplist["values"] = option_hash

droplist["default_value"] = aws_ems[0].id.to_s

$evm.log("info", "populateAwsProviders Automate Method Ended")

exit MIQ_OK
