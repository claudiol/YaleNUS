#
# Description: Populate a dynamic drop down list with available AWS instance sizes
#

###### TRACERS ######
# Method for logging
def log(level, message)
  @method = 'populateOpenStackInstanceSizes'
  $evm.log(level, "#{@method} - #{message}")
end

def info(message)
  log(:info, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

info("Automate Method Started")

# Allowed flavors are listed here. Add or remove flavors here to modify what the user can see.
allowed_flavors = ["t2.micro", "t2.small", "m3.medium", "m3.large"]

droplist = $evm.object

droplist["data_type"] = "String"
droplist["required"] = "true"

# Retrieve ext_management_system
ems = $evm.vmdb("ems_openstack").first # assuming only one of each provider type.
$evm.log("info", "fetched region: #{ ems.name }")

default_value = ems.flavors[0].id.to_s
$evm.log("info", "Default value: #{ default_value }")

# Create droplist values
option_hash = {}
ems.flavors.each { |flavor|
  if ems.type == "EmsAmazon"
    if allowed_flavors.include? flavor.name
      key = flavor.id.to_s
      value = "CPUs: #{ flavor.cpus }, Memory: #{ (flavor.memory / 1024.0**3).round(1) } GB (#{ flavor.name })"
      $evm.log("debug", "Adding '#{ key }':'#{ value }' to droplist values")
      option_hash[key] = value
    end
  else
    key = flavor.id.to_s
    value = "CPUs: #{ flavor.cpus }, Memory: #{ (flavor.memory / 1024.0**3).round(1) } GB (#{ flavor.name })"
    $evm.log("debug", "Adding '#{ key }':'#{ value }' to droplist values")
    option_hash[key] = value
  end
}
info("Generated droplist options: #{ option_hash }")
droplist["values"] = option_hash

droplist["default_value"] = default_value

info("Automate Method Ended")

exit MIQ_OK
