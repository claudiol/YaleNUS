###################################
#
# CloudForms Automate Method: aws_elb_regions
#
# This method is used to search for all ELB regions
#
###################################
#
# Method for logging
#
def log(level, message)
  @method = 'aws_elb_regions'
  $evm.log(level, "#{@method} - #{message}")
end
$evm.log("info", "====== RETRIEVE AMAZON REGIONS ===== Automate Method Started")
#
#            Method Code Goes here
#

# Load the aws-sdk
require "aws-sdk"


# @!method available_regions
# List of available regions in EC2
#
# @return [AWS::RegionCollection] .
#
def available_regions
  return ec2_instance.regions
end


begin
  dialog_field = $evm.object
  access_key_id = nil
  secret_access_key = nil

  # Get the Amazon authentication credentials...
  ems = $evm.vmdb(:ems_amazon).first
  
  if ems.nil?
    # Get the values from the schema ...
    access_key_id ||= $evm.object['access_key_id']
    secret_access_key = $evm.object.decrypt('secret_access_key')
  else
    access_key_id ||= ems.authentication_userid
    secret_access_key = ems.authentication_password
  end

  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  # Create the basic EC2 object
  ec2_instance = AWS::EC2.new(:region => default_region)

  # Retrieve the available EC2 Regions
  regions = ec2_instance.regions

  # Create some local variables ...

  # Dynamic list to add values to the dialog dynamic list ...
  list = {}

  # Count of regions ...
  count = 0

  # Save first entry and make it the default region
  first = nil

  # Go through all regions returned from EC2 and add them to list
  regions.each do |k|
    count += 1
    if count == 1
      first = k.name
    end
    $evm.log("info", "REGIONS: #{k.name} ")
    list[k.name]  = "#{k.name}"
  end

  list[""] = ""

  $evm.log("info", "LIST: #{list.inspect} ")

  # Add list to dialog dynamic list ...
  $evm.object["values"] = list

  # Make the first entry the default value
  $evm.object["default_value"] = first

  $evm.object['selected_aws_region'] = $evm.root['dialog_aws_region']

  $evm.log("info", "====== REGION: #{$evm.object['dialog_aws_region']}")
  $evm.log("info", "====== SELECTED REGION: #{$evm.object['selected_aws_region']}")

  $evm.log("info", "====== RETRIEVE AMAZON REGIONS =====  Automate Method ")

  #task = $evm.root['service_template_provision_task"']
  #$evm.log("info", "===========================================")
  #$evm.log("info", "Listing ROOT Attributes:")
  #$evm.root.attributes.sort.each { |k, v| $evm.log("info", "\t#{k}: #{v}")}
  #$evm.log("info", "===========================================")

  #stp_task = $evm.root["service_template"]
  #$evm.log("info", "===========================================")
  #$evm.log("info", "Listing task Attributes:")
  #stp_task.attributes.sort.each { |k, v| $evm.log("info", "\t#{k}: #{v}")}
  #$evm.log("info", "===========================================")

  exit MIQ_OK

rescue => exception
  $evm.log("info", "====== EXCEPTION IN RETRIEVE AMAZON REGIONS =====")
  $evm.log("info", exception.message)
end
