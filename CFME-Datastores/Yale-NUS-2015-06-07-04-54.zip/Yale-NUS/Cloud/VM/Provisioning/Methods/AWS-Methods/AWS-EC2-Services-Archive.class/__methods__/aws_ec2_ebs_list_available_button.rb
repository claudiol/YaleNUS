###################################
#
# CloudForms Automate Method: aws_ec2_ebs_all_list
#
# This method is used to search for all EBSs that are owned by a user in all allowed regions
#
###################################
#
# Method for logging
def log(level, message)
  @method = 'aws_ec2_ebs_all_list'
  $evm.log(level, "#{@method} - #{message}")
end
#
def dumpRoot
  $evm.log("info", "#{@method} - Root:<$evm.root> Begin Attributes")
  $evm.root.attributes.sort.each { |k, v| $evm.log("info", "#{@method} - Root:<$evm.root> Attributes - #{k}: #{v}")}
  $evm.log("info", "#{@method} - Root:<$evm.root> End Attributes")
  $evm.log("info", "")
end

# dump root object attributes
dumpRoot
#
log(:info, "===== AWS List All EBSs in All Available Regions ==== Automate Method Started")
#            Method Code Goes here
#

# Load the aws-sdk
require "aws-sdk"


begin

  dialog_field = $evm.object
  vm = $evm.root['vm']
  ems = vm.ext_management_system

  region = ems.hostname

  #####RBAC sample, setting the filter mode

  this_user = $evm.root['user'].userid.downcase
  log(:info, "this_user : #{this_user.inspect}")
  #AWS doesn't like underscores, dashes or spaces so strip
  this_user_group = $evm.root['user'].ldap_group.downcase.gsub(/[\W+]|[_]/,'')
  log(:info, "this_user_group (cleaned of underscores): #{this_user_group.inspect}")


  filter_user = 'none' # values user, group, none

  if this_user_group  == 'evmgroupsuperadministrator' #remember that the naming removes any underscores, always lower
    filter_user = 'none'
  elsif this_user_group.nil?
    filter_user = 'user'
  elsif this_user_group == 'cloudforms'  #remember to tag all lower case, naming stripped with the REGEX
    filter_user = 'user'
  else
    filter_user = 'group'
  end

  # Dynamic list to add values to the dialog dynamic list ...
  list = {}

  # Count of regions ...
  count = 0

  # Save first entry and make it the default region
  first = nil

  # Go through all regions returned from EC2 and add them to list

  # Get the Amazon authentication credentials...
  access_key_id ||= ems.authentication_userid
  secret_access_key = ems.authentication_password

  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  # Create the basic EC2 object
  #ec2_instance = AWS::EC2.new( :region => default_region )

  # log(:info, "+++++++++++++++++++ Dump of Allowed Regions : #{allowed_regions} +++++++++++++++++++++++")


    ebs_instance = AWS::EC2.new( :region => region )

    # log(:info, "++++++++++++ Now Processing Region : #{r}++++++++++++++++++++")
    # log(:info, "++++++++++++ User ID : #{this_user}+++++++++++++++++++++++")
    # log(:info, "++++++++++++ Group ID : #{this_user_group}+++++++++++++++++")


    if filter_user =='user'
      ebs = ebs_instance.volumes.with_tag("userid", "#{this_user}")
    elsif filter_user =='group'
      ebs = ebs_instance.volumes.with_tag("usergroup", "#{this_user_group}")
    else #should only fall through for Admin - group EvmGroup-super_administrator
      ebs = ebs_instance.volumes
    end

    log(:info, "EBS : #{ebs.inspect}")


    # Create some local variables ...


    unless ebs.nil?
      ebs.each do |e|
        if e.status == :available
          log(:info, "++++++++++ EBS : #{e.inspect} ++++++++++++++++++++++")
          name = e.tags.values_at("Name")
          log(:info, "+++++++++++++ Name : #{name} +++++++++++++++++++")
          count += 1
          if count == 1
            first = e.id
          end
          log(:info, "EBS: #{e.id} ")
          list["#{e.id}|#{region}|#{name}"]  = "#{e.id}|#{region}"
        else
          log(:info, "+++++++++++ EBS #{e} is in use +++++++++++++++++++++++++++++++++")
        end
      end
    end

  list[""] = ""

  log(:info, "LIST: #{list.inspect} ")

  # sort_by: value / description / none
  $evm.object["sort_by"] = "description"
  # sort_order: ascending / descending
  $evm.object["sort_order"] = "ascending"
  # data_type: string / integer
  $evm.object["data_type"] = "string"
  # required: true / false
  $evm.object["required"] = "true"
  # Add list to dialog dynamic list ...
  $evm.object["values"] = list


  # Make the first entry the default value
  $evm.object["default_value"] = first


  log(:info, "Dialog Inspect: #{$evm.object.inspect}")

  log(:info, "====== RETRIEVE AMAZON ELASTIC BLOCK STORAGE =====  Automate Method Ended")
  exit MIQ_OK

rescue => exception
  log(:info, "====== EXCEPTION IN RETRIEVE AMAZON ELASTIC BLOCK STORAGE =====")
  log(:info, exception.message)
end
