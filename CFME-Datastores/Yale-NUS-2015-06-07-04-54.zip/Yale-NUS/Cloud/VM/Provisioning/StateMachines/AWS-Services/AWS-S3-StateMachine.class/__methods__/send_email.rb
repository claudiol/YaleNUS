###################################

begin
  @method = '======= AWS S3 Email Method =========='
  $evm.log("info", "#{@method} - EVM Automate Method Started")

  # Turn of verbose logging
  @debug = true

 # Get from_email_address from model unless specified below
  from = nil
  from ||= $evm.object['from_email_address']

  # Get signature from model unless specified below
  signature = nil
  signature ||= $evm.object['signature']

  appliance ||= $evm.root['miq_server'].ipaddress

  ###################################
  #
  # Method: boolean
  #
  ###################################
  def boolean(string)
    return true if string == true || string =~ (/(true|t|yes|y|1)$/i)
    return false if string == false || string.nil? || string =~ (/(false|f|no|n|0)$/i)

    # Return false if string does not match any of the above
    $evm.log("info","Invalid boolean string:<#{string}> detected. Returning false") if @debug
    return false
  end

  def email_enduser(appliance, from, signature) 
    
    #
    # Get VM Owner Name and Email
    #
    evm_owner_email = $evm.root['email_address'] 
    bucket_name = $evm.root['bucket_name']
    region = $evm.root['bucket_aws_region']
    
    to = nil
    to = evm_owner_email unless evm_owner_email.nil?
    
    if to.nil?
      $evm.log("info", "#{@method} Email not sent because no recipient specified.")
      exit MIQ_OK
    end

    # Assign original to_email_Address to orig_to for later use
    orig_to = evm_owner_email

    # Set email Subject
    subject = "Your AWS S3 bucket request has Completed - AWS S3: [#{bucket_name}]"


    # Set the opening body to Hello
    body = "Hello, "
    body += "This email is being sent by EVM to inform you of the provisioning of a new AWS S3 Bucket.<br>"
    body += "This new AWS S3 Bucket requires verification in the Amazon EC2 console.<br>"
    body += "Once that has been completed, use this message to inform the "
    body += "requester that their new AWsS3 Bucket is ready.<br><br>"
    body += "-------------------------------- <br>"
    body += "Forward the message below to <br>"
    body += "#{orig_to}<br>"
    body += "-------------------------------- <br><br>"
    body += "<br>"

    body += "-------------------------------- <br>"
    body += " Amazon S3 Bucket Info<br>"
    body += "-------------------------------- <br><br>"
    body += "<br><br><b>S3 Bucket Name  :</b> #{bucket_name}"
    body += "<br><br><b>S3 Amazon Region:</b> #{region}"
    body += "<br><br> If you have any issues with your new AWS S3 Bucket please contact Support."
    body += "<br><br> Thank you,"
    body += "<br> #{signature}"
    
    #
    # Send email to user
    #
    $evm.log("info", "#{@method} - Sending email to <#{to}> from <#{from}> subject: <#{subject}>") if @debug
    $evm.execute('send_email', to, from, subject, body)
  end
  
  email_enduser(appliance, from, signature)
  
  
  #
  # Exit method
  #
  $evm.log("info", "#{@method} - EVM Automate Method Ended")
  exit MIQ_OK

  #
  # Set Ruby rescue behavior
  #
rescue => err
  $evm.log("error", "#{@method} - [#{err}]\n#{err.backtrace.join("\n")}")
  exit MIQ_STOP
end
