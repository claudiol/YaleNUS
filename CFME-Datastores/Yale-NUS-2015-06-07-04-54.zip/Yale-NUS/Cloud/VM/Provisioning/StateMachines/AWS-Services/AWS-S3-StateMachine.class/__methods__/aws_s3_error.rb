#            Automate Method
#
$evm.log("info", "AWS S3 Error - Automate Method Started")
#
#            Method Code Goes here
#

$evm.log("info", "Error creating AWS S3 bucket")

#
#
#
$evm.log("info", "AWS S3 Error - Automate Method Ended")
exit MIQ_ABORT
