#
#            Automate Method
#
$evm.log("info", "Automate Method Started")
#
#            Method Code Goes here
#

#
#
#
$evm.log("info", "Automate Method Ended")
exit MIQ_OK
