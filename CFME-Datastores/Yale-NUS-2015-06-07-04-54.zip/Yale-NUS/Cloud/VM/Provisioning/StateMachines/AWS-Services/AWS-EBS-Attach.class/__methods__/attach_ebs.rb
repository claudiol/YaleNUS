#
#            Automate Method
#
# Method to validate the name of the RDS Instance:
#
# Constraints: Must contain from 1 to 63 (1 to 15 for SQL Server) alphanumeric characters or hyphens.
# First character must be a letter. Cannot end with a hyphen or contain two consecutive hyphens.
#
# Method for logging
def log(level, message)
  @method = 'create_attach_ebs_volume_button'
  $evm.log(level, "#{@method} - #{message}")
end
#
require 'aws-sdk'

@method = "delete-rds-instance"
$evm.log("info", "======= #{@method} ====== Automate Method Started")

$evm.log("info", "========== AWS #{@method} ATTRIBUTE LOG =================================")
$evm.log("info", "Listing ROOT Attributes:")
$evm.root.attributes.sort.each { |k, v| $evm.log("info", "\t#{k}: #{v}")}
$evm.log("info", "=========== AWS #{@method}ATTRIBUTE LOG ================================")

begin
  access_key_id = nil
  secret_access_key = nil

  # Addiong the user info and downcasing it
  # user = $evm.root['user'].userid.downcase.gsub(/[@]|[.]/, '-')
  # log(:info, "++++++++++++++++ Userid : #{user} ++++++++++++++++++++++++++")


  #AWS doesn't like underscores, dashes or spaces so strip for group
  user_group = $evm.root['user'].ldap_group.downcase.gsub(/[\W+]|[_]/,'')

# Get the Amazon authentication credentials...
  access_key_id ||= $evm.object['access_key_id']
  secret_access_key = $evm.object.decrypt('secret_access_key')
  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  # Get the name of the bucket name from the request ... validate_bucket_name adds it
  #elb_name = $evm.root['elb_name']
  # Retrieve the region from the dialog

  # Retrieve all the Dialog items to provision the RDS Service

  # auto_upgrade = $evm.root.attributes['dialog_auto_upgrade']
  # rds_storage = $evm.root.attributes['dialog_rds_alloc_storage']
  # backup_period = $evm.root.attributes['dialog_rds_backup_period']
  # db_auto_backups = $evm.root.attributes['dialog_rds_db_auto_backups']
  # db_az_deployment = $evm.root.attributes['dialog_rds_db_az_deployment']
  # db_engine = $evm.root.attributes['dialog_rds_db_engine']
  # db_instance_class = $evm.root.attributes['dialog_rds_db_instance_class']
  # db_name = $evm.root.attributes['dialog_rds_db_name']
  # db_password = $evm.root.attributes['dialog_rds_db_password']
  # db_port = $evm.root.attributes['dialog_rds_db_port']
  # db_subnet = $evm.root.attributes['dialog_rds_db_subnet']
  # db_user_id = user
  # #db_user_id = $evm.root.attributes['dialog_rds_db_user_id']
  # db_version = $evm.root.attributes['dialog_rds_db_version']
  # db_vpc = $evm.root.attributes['dialog_rds_db_vpc']
  # instance_name = $evm.root.attributes['dialog_rds_instance_name']
  # rds_public_access = $evm.root.attributes['dialog_rds_public_access']
  # rds_use_iops = $evm.root.attributes['dialog_rds_use_iops']

  instance_name = $evm.root.attributes['dialog_list_rds']
  region      = $evm.root['default_aws_region']
  # auto_backups = (db_auto_backups) ? true : false
  # az_deployment = (db_az_deployment) ? true : false
  # use_iops = (rds_use_iops) ? 1 : 0
  # public_access = (rds_public_access) ? true : false

  # $evm.log("info", "===> Region: #{region}")

  # Create the basic EC2 object
  ec2_instance = AWS::EC2.new(:region => region)
  #rds_instance = AWS::RDS.new(:region => region)

  rds = AWS::RDS.new(:region => region)

  #rds.db_instances.each do |db|
  db = rds.db_instances["#{instance_name}"]
    # ap db.db_instance_identifier.match('admin')
    #ap db.id
    #ap db.master_username
    #instance = db.db_instance_identifier
    #if instance == 'rbuiltatest1'
      db.delete(:skip_final_snapshot => true)
    #end
  #end

  # upgrade = (auto_upgrade) ? true : false
  #
  # options={ :db_name => "#{db_name}", :allocated_storage => rds_storage.to_i, :db_instance_class => "#{db_instance_class}",
  #           :engine => "#{db_engine}", :master_username => "#{db_user_id}", :master_user_password => "#{db_password}",
  #           :auto_minor_version_upgrade => upgrade, :backup_retention_period => backup_period.to_i, :multi_az => az_deployment,
  #           :port => db_port.to_i, :master_username => db_user_id,  :engine_version => "#{db_version}",
  #           :db_instance_identifier => "#{instance_name}", :publicly_accessible => public_access }
  # rds_instance.db_instances.create(instance_name, options)
  #
  #
  # Now Tag the newly created RDS from the username/groupid and volume name
  # ec2.volumes["#{volume.id}"].tags["userid"] = "#{user}"
  # ec2.volumes["#{volume.id}"].tags["usergroup"] = "#{user_group}"
  # ec2.volumes["#{volume.id}"].tags["Name"] = "#{vol_name}"

  #Email info
  vars = Hash.new
  vars[:type] = "delete_rds_instance"
  vars[:action] = "Deleted"
  vars[:service_name] = "AWS RDS"
  vars[:instance_name] = instance_name
  #vars[:selected_device_name] = selected_device_name
  vars[:db_name] = rds_instance.db_instances[db_name]

  require 'json'
  require 'uri'
  args = "payload=#{vars.to_json}"
  args = URI.escape(args)
  $evm.log("info", "============== vars: #{vars.inspect}")
  $evm.log("info", "============== args: #{args.inspect}")
  $evm.instantiate("/Yale/Methods/Emails/Email_Owner?#{args}")

  #
  $evm.log("info", "======= #{@method} ====== Automate Method Ended")
  exit MIQ_OK
rescue => err
  $evm.log("info", "====== Automate Method Ended ======")
  $evm.log("info", "====== AWS RDS Exception ======")
  $evm.log("info", "======= #{err.message} ====== Automate Method Ended")
  exit MIQ_ABORT
end
