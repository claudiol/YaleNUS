#
# Description: This method is used to Assign a Public IP to an OpenStack Instance
#

###### TRACERS ######
# Method for logging
def log(level, message)
  @method = 'assign_floating_ip'
  $evm.log(level, "#{@method} - #{message}")
end

def info(message)
  log(:info, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

info("Automate Method Started")

require 'fog'

def has_public_ip(fog_vm)
  # assumes only one network interface.
  addresses = fog_vm.addresses.values[0]
  floating_ips = addresses.select { |address| address['OS-EXT-TYPE:type']=='floating' }
  if floating_ips.length > 0
    return true
  end
  return false
end


vm = $evm.root['vm']
ems = vm.ext_management_system

# Set up Fog connection to Openstack.
os_user_id = ems.authentication_userid
os_password = ems.authentication_password
os_auth_url = "http://#{ ems.hostname }:#{ ems.port }/v2.0/tokens"
os_tenant = ems.cloud_tenants.find(vm.cloud_tenant_id).first.name
compute = Fog::Compute.new({:provider => ems.emstype,
                            :openstack_username => os_user_id,
                            :openstack_api_key => os_password,
                            :openstack_auth_url => os_auth_url,
                            :openstack_tenant => os_tenant})


if has_public_ip(fog_vm)
  info("VM already has a public IP!")
  exit MIQ_ABORT
end

# Get an unattached floating IP or create one if all are attached.
fog_floating_ip = compute.addresses.select { |a| a.instance_id == nil }.first
if fog_floating_ip == nil
  # exception handling req here if not able to allocate address.
  begin
    fog_floating_ip = compute.allocate_address
  rescue
    exit MIQ_ABORT
  end
end

# Get the VM in Fog and attach the Floating IP.
fog_vm = compute.servers.select { |s| s.id == vm.uid_ems }.first
fog_vm.associate_address(fog_floating_ip.ip)

# After association, refresh VMDB's info on the VM
vm.refresh

info("Automate Method Ended")

exit MIQ_OK
