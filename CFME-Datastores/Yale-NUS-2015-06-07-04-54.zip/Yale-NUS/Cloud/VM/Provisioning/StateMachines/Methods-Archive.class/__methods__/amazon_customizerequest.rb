#
# Method: process_amazon
#
#
#################################

# Method for logging
def log(level, message)
  @method = 'amazon_CustomizeRequest'
  $evm.log(level, "#{@method} - #{message}")
end

def dumpRoot
  $evm.log("info", "#{@method} - Root:<$evm.root> Begin Attributes")
  $evm.root.attributes.sort.each { |k, v| $evm.log("info", "#{@method} - Root:<$evm.root> Attributes - #{k}: #{v}")}
  $evm.log("info", "#{@method} - Root:<$evm.root> End Attributes")
  $evm.log("info", "")
end

def process_amazon(mapping, prov )
# Get information from the template platform
# Check for ws_values in prov object
  if prov.options.has_key?(:ws_values)
    ws_values = prov.options[:ws_values]
    log(:info, "Got Incoming WS_values>")
    log(:info, "ws_values #{ws_values}")
  end

  template = prov.vm_template
  log(:info, "Got the template")

  case mapping
    when 0
      # No mapping
    when 1
      provider = template.ext_management_system
      raise "Provider not found for template [#{template.name}" if provider.nil?
      instance_types = provider.flavors
      instance_types.each do |i|
        if i.name ==  ws_values[:flavor]
          puts "Checking passed in Flavor: [#{ws_values[:flavor]}] against Instance Type: [#{i.name}]"
          prov.set_option(:instance_type, [i.id,"#{i.name}':'#{i.description}"])
          log(:info, "Setting Instance type to: #{i.name}")
        end
      end

    #set Key pair
      
    keypairs = provider.key_pairs
    log(:info, "Keypairs: #{keypairs.inspect}:\nWSvalue: cf322}")
        
    keypairs.each do |k|
        log(:info, "K.name : #{k.name}")
        if k.name == "cf322"
          prov.set_option(:guest_access_key_pair, [k.id, k.name])
          log(:info, "Setting Access Key type to: #{k.name}")
        end
      end

      availability_zones = provider.availability_zones
      availability_zones.each do |a|
        if a.name == ws_values[:availability_zone]
          log(:info, "a_zone: id: #{a.id} name: #{a.name}")

          #current_obj = $evm.current
          #current_obj["availability_zone"] = a
          prov.set_option(:placement_availability_zone,[a.id, a.name])
        end
      end

      unless ws_values[:vpc].blank?
        network = $evm.vmdb("cloud_network").find_by_ems_ref(ws_values[:vpc])
        log(:info, "network: #{network.inspect} for vpc_id: #{ws_values[:vpc]}")
      end
      unless ws_values[:vpc].blank?
        subnet = $evm.vmdb("cloud_subnet").find_by_ems_ref(ws_values[:subnet_id])
        log(:info, "subnet: #{subnet}")
      end
      prov.set_option(:cloud_subnet, [subnet.id ,subnet.name]) unless subnet.nil?
      prov.set_option(:cloud_network, [network.id ,network.name]) unless network.nil?
  
      #unless ws_values[:vm_tags].blank?
      #  tag = ws_values[:vm_tags]
      #  prov.set_option(:vm_tags, ["#{tag}"]) unless tag.nil?
      #end

        # keypairs = provider.key_pairs
        # keypairs.each do |k|
        #   if k.name ==  ws_values[:guest_access_key_pair]
        #     prov.set_option(:guest_access_key_pair, [k.id,k.name])
        #     log(:info, "Setting Access Key type to: #{k.name}")
        #   end

        #end
    end

  end # end process_amazon

# Get provisioning object
prov = $evm.root["miq_provision"]

$evm.log("info", "Yale Domain amazon_CustomizeRequest: Provisioning ID:<#{prov.id}> Provision Request ID:<#{prov.miq_provision_request.id}> Provision Type: <#{prov.type}>")

# dump root object attributes
dumpRoot


mapping = 1
process_amazon(mapping, prov)
