#
# Description: This method is used to create a new volume and attach to an OpenStack Instance
#

###### TRACERS ######
# Method for logging
def log(level, message)
  @method = 'assign_floating_ip'
  $evm.log(level, "#{@method} - #{message}")
end

def info(message)
  log(:info, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

info("Automate Method Started")

require 'fog'

def create_new_vol_attachment_path(fog_vm)
  # assumes each VM will have no more than 25 volume attachments.
  possible_suffixes = ('b'..'z').to_set
  reserved_letters = fog_vm.volume_attachments.collect { |a| a['device'][-1] }
  usable_suffixes = possible_suffixes - reserved_letters
  return '/dev/vd' + usable_suffixes.first
end


dump_root

# Retrieve volume creation options.
name = $evm.root.attributes['dialog_name'].to_s
size = $evm.root.attributes['dialog_size'].to_s
description = $evm.root.attributes['dialog_description'].to_s
info("Disk name: #{ name }")
info("Disk size: #{ size }")
info("Disk description: #{ description }")

vm = $evm.root['vm']
ems = vm.ext_management_system

# Set up Fog connection to Openstack.
os_user_id = ems.authentication_userid
os_password = ems.authentication_password
os_auth_url = "http://#{ ems.hostname }:#{ ems.port }/v2.0/tokens"
os_tenant = ems.cloud_tenants.find(vm.cloud_tenant_id).first.name
compute = Fog::Compute.new({:provider => ems.emstype,
                            :openstack_username => os_user_id,
                            :openstack_api_key => os_password,
                            :openstack_auth_url => os_auth_url,
                            :openstack_tenant => os_tenant})

# Create desired volume.
vol = compute.create_volume(name,
                            description,
                            size,
                            { 'availability_zone' => vm.availability_zone.ems_ref })
vol_id = vol.body['volume']['id']

# Attach to the VM.
fog_vm = compute.servers.select { |s| s.id == vm.uid_ems }.first
dev_path = create_new_vol_attachment_path(fog_vm)
compute.attach_volume(vol_id, vm.ems_ref, dev_path)

# After release, refresh VMDB's info on the VM
vm.refresh

info("Automate Method Ended")

exit MIQ_OK
