###################################
#
# CloudForms Automate Method: CreateVolume
#
# This method is used to create an OpenStack Cinder Volume
#
###################################

###### TRACERS ######
# Method for logging
def log(level, message)
  $evm.log(level, "#{message}")
end

def info(message)
  log(:info, message)
end

def error(message)
  log(:error, message)
end

def debug(message)
  log(:debug, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

def create_new_vol_attachment_path(fog_vm)
  # assumes each VM will have no more than 25 volume attachments.
  possible_suffixes = ('b'..'z').to_set
  reserved_letters = fog_vm.volume_attachments.collect { |a| a['device'][-1] }
  usable_suffixes = possible_suffixes - reserved_letters
  return '/dev/vd' + usable_suffixes.first
end

begin
  
  info("Automate method started.")
  
  dump_root
  
  require 'fog'
  
  # cinder volume and VM attributes
  vm_id = $evm.object["vm_id"]
  cinder_volume_id = $evm.object["cinder_volume_id"]
  if cinder_volume_id.nil?
    cinder_volume_id = $evm.root["yalenus_cinder_volume_id"]
  end

  
  # Set up Fog connection to Openstack.
  os_user_id = $evm.object["os_authentication_userid"]
  os_password = $evm.object["os_authentication_password"]
  os_auth_url = $evm.object["os_authentication_url"]
  os_tenant = $evm.object["os_tenant"]
  info("Fog openstack_username: #{ os_user_id }, openstack_api_key: #{ os_password }, openstack_auth_url: #{ os_auth_url }, openstack_tenant: #{ os_tenant }")
  
  fog_conn = Fog::Compute.new({:provider => 'openstack',
                              :openstack_username => os_user_id,
                              :openstack_api_key => os_password,
                              :openstack_auth_url => os_auth_url,
                              :openstack_tenant => os_tenant})
  
  info("Fetching VM for association")
  vm = $evm.vmdb(:vm).find(vm_id)
  fog_vm = fog_conn.servers.select { |s| s.id == vm.uid_ems }.first
  info("VM fetched")

  info("Fetching volume #{ cinder_volume_id }")
  vol = fog_conn.volumes.select { |v| v.id == cinder_volume_id }.first
  info("Volume #{ vol.name } fetched. Checking if status is available.")
  
  # Ensure that the Volume is ready for attachment.
  retries = 0
  until vol.status == 'available' or retries >= $evm.object['retries'] do
    info("Volume status is not 'available'")
    sleep $evm.object['sleep']
    retries += 1
    vol.reload
    info("Retry #{ retries } of #{ $evm.object['retries'] }. Volume not yet available for attachment (#{ vol.status }). Sleeping...")
  end

  unless vol.status == 'available'
    error("Timeout while waiting for volume #{vol_id} to be available for attachment. Volume Status: #{ vol.status }")
    exit MIQ_ABORT
  end

  # Attach to the VM.
  dev_path = create_new_vol_attachment_path(fog_vm)
  info("Attaching to VM now on #{ dev_path }")
  response = fog_conn.attach_volume(vol.id, vm.ems_ref, dev_path)

  unless [200, 202].include? response.status
    error("Volume did not attach successfully.")
    exit MIQ_ABORT
  end

  # Ensure that the Volume has attached
  retries = 0
  until vol.status == 'in-use' or retries >= $evm.object['retries'] do
    info("Volume status is not 'in-use'")
    sleep $evm.object['sleep']
    retries += 1
    vol.reload
    info("Retry #{ retries } of #{ $evm.object['retries'] }. Volume not yet in use for instance (#{ vol.status }). Sleeping...")
  end

  unless vol.status == 'in-use'
    error("Timeout while waiting for volume #{vol_id} to be successfully attached. Volume Status: #{ vol.status }")
    exit MIQ_ABORT
  end

  info("Attached successfully")

  exit MIQ_OK
end
