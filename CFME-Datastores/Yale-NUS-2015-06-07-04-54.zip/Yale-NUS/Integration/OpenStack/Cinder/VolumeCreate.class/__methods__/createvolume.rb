###################################
#
# CloudForms Automate Method: CreateVolume
#
# This method is used to create an OpenStack Cinder Volume
#
###################################

###### TRACERS ######
# Method for logging
def log(level, message)
  $evm.log(level, "#{message}")
end

def info(message)
  log(:info, message)
end

def error(message)
  log(:error, message)
end

def debug(message)
  log(:debug, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

def clean_vol_name(given_name)
  info("Create volume name from given name: #{given_name}")
  # this creates a Cinder name that follows the rules below
  # max length is 32 chars, all lower case, no underscores or dashes except those as part of composition
  # pattern of userid-group name limited-name passed in
  # regex used: /[\W+]|[_]/  Strips all non word characters and underscores (underscore is part of /W)
  # length of the group portion of the name is defined below
  group_length_limit = 15
  my_user = $evm.root['user']

  info("userid ===> #{my_user.userid}")
  info("group membership ===> #{my_user.miq_group.description}")

  cleaned_group = my_user.miq_group.description.downcase.gsub(/[\W+]|[_]/, '').first(group_length_limit)

  info("user group normalized (15 chars) ===> #{cleaned_group}")

  # Get the name of the Volume name from the request and clean it
  clean_name = given_name.downcase.gsub(/[\W+]|[_]/, '')
  $evm.log("info", "cleaned passed name ===> #{clean_name}")

  cleaned_name = "#{my_user.userid}-#{cleaned_group}-#{clean_name}".first(255)
  info("Fully crafted name (255 char max): #{cleaned_name}")
  return cleaned_name
end

begin
  
  info("Automate method started.")
  
  require 'fog'
  
  # cinder volume attributes
  cinder_volume_name = clean_vol_name($evm.object["cinder_volume_name"])
  cinder_volume_description = $evm.object["cinder_volume_description"]
  cinder_volume_size = $evm.object["cinder_volume_size"]
  cinder_volume_az = $evm.object["cinder_volume_az"]

  # Set up Fog connection to Openstack.
  os_user_id = $evm.object["os_authentication_userid"]
  os_password = $evm.object["os_authentication_password"]
  os_auth_url = $evm.object["os_authentication_url"]
  os_tenant = $evm.object["os_tenant"]
  info("Fog openstack_username: #{ os_user_id }, openstack_api_key: #{ os_password }, openstack_auth_url: #{ os_auth_url }, openstack_tenant: #{ os_tenant }")
  
  fog_conn = Fog::Compute.new({:provider => 'openstack',
                              :openstack_username => os_user_id,
                              :openstack_api_key => os_password,
                              :openstack_auth_url => os_auth_url,
                              :openstack_tenant => os_tenant})
  
  # Create desired volume.
  info("Creating new volume")
  response = fog_conn.create_volume(cinder_volume_name,
                                    cinder_volume_description,
                                    cinder_volume_size,
                                    { 'availability_zone' => cinder_volume_az })
  
  unless [200, 202].include? response.status
    exit MIQ_ABORT
  end
  
  info("Volume Created")
  
  vol_id = response.body['volume']['id']
  vol = fog_conn.volumes.select { |v| v.id == vol_id }.first
  $evm.object["cinder_volume_id"] = vol.id
  $evm.root["yalenus_cinder_volume_id"] = vol.id
  
  exit MIQ_OK
  
end
