###################################
#
# CloudForms Automate Method: DeleteVolume
#
# This method is used to delete an OpenStack Cinder Volume
#
###################################

###### TRACERS ######
# Method for logging
def log(level, message)
  $evm.log(level, "#{message}")
end

def info(message)
  log(:info, message)
end

def error(message)
  log(:error, message)
end

def debug(message)
  log(:debug, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

begin
  
  info("Automate method started.")
  
  require 'fog'
  
  # cinder volume ID
  cinder_volume_id = $evm.object["cinder_volume_id"]

  # Set up Fog connection to Openstack.
  os_user_id = $evm.object["os_authentication_userid"]
  os_password = $evm.object["os_authentication_password"]
  os_auth_url = $evm.object["os_authentication_url"]
  os_tenant = $evm.object["os_tenant"]
  info("Fog openstack_username: #{ os_user_id }, openstack_api_key: #{ os_password }, openstack_auth_url: #{ os_auth_url }, openstack_tenant: #{ os_tenant }")
  
  fog_conn = Fog::Compute.new({:provider => 'openstack',
                              :openstack_username => os_user_id,
                              :openstack_api_key => os_password,
                              :openstack_auth_url => os_auth_url,
                              :openstack_tenant => os_tenant})

  volume = fog_conn.volumes.get(cinder_volume_id)
  volume_name = volume.name
    
  if volume.destroy == false
    error("Unable to delete volume #{volume_name} (#{cinder_volume_id})")
    exit MIQ_ABORT
  end

  info("Volume successfully deleted")
  
  info("Automate method ended.")

  exit MIQ_OK
end
