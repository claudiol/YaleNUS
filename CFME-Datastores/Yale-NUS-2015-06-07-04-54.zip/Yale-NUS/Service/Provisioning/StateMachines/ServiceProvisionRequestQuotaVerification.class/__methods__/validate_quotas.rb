#
# Description: This method validates the provisioning request using the values
# [quota_max_cpu, quota_max_memory, quota_max_storage] from the group associated with
# the project tag specified in the request.
#

###### UTILITY METHODS ######
# Method for logging
def log(level, message)
  @method = 'validate_request'
  $evm.log(level, "#{message}")
end

# Convenience methods
def info(message)
  log(:info, message)
end

def debug(message)
  log(:debug, message)
end

def dump_root
  info("Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| info(" Attribute - #{k}: #{v}") }
  info("Root:<$evm.root> Attributes - End")
  info("")
end


def dump_attributes(object)
  info("Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| info("  #{k} = #{v.inspect}") }
  info("End Attributes [object.attributes]")
  info("")
end

###### UTILITY METHODS ######

require 'json'

class Resources
  attr_accessor :cpu, :memory, :storage

  def initialize(cpu, memory, storage)
    @cpu, @memory, @storage = cpu.to_i, memory.to_i, storage.to_i
  end

  def inspect
    return "CPU: #{self.cpu} Memory: #{self.memory} Storage: #{self.storage}"
  end
  
  def +(rhs)
    # make sure we're dealing with the same class of object.
    unless rhs.is_a? self.class
      raise "Doing an operation on an object of an incompatible class(#{rhs.class})."
    end

    # duplicate this object and return the dupe after the operation.
    dupe = self.dup
    dupe.cpu = dupe.cpu.to_i + rhs.cpu.to_i
    dupe.memory = dupe.memory.to_i + rhs.memory.to_i
    dupe.storage = dupe.storage.to_i + rhs.storage.to_i

    return dupe
  end

  def -(rhs)
    # make sure we're dealing with the same class of object.
    unless rhs.is_a? self.class
      raise "Doing an operation on an object of an incompatible class(#{rhs.class})."
    end

    # duplicate this object and return the dupe after the operation.
    dupe = self.dup
    dupe.cpu = dupe.cpu.to_i - rhs.cpu.to_i
    dupe.memory = dupe.memory.to_i - rhs.memory.to_i
    dupe.storage = dupe.storage.to_i - rhs.storage.to_i

    return dupe
  end

  def is_overutilized?
    if self.cpu < 0 or self.memory < 0 or self.storage < 0
      return true
    end
    return false
  end
end

def get_filter_value(group, name)
  filter = group.filters['managed'].select { |f| f[0].starts_with? "/managed/#{name}/" }.first.first
  value = filter.split('/').last
  return value
end

def get_project_quotas(project_tag)
  quotas = {}

  # Get group associated with project.
  filter_tag = "/managed/#{project_tag}"
  group = $evm.vmdb('miqGroup').all.select { |g| g.filters!=nil && (g.filters['managed'].include? ["#{filter_tag}"]) }.first
  info("Associated group retrieved: #{group.description}")
  quotas = Resources.new(0,0,0)
  quotas.cpu = get_filter_value(group, 'quota_max_cpu')
  quotas.memory = get_filter_value(group, 'quota_max_memory')
  quotas.storage = get_filter_value(group, 'quota_max_storage')
  info("Project quota: #{quotas.inspect}")
  return quotas  
end

def get_project_allocations(project_tag)
  # Get already allocated resource levels.
  allocated = Resources.new(0,0,0)
  group_vms = $evm.vmdb('vm').all.select { |vm| vm.tags.include? "#{project_tag}" }
  group_vms.each { |vm|
    allocated.cpu += vm.hardware.numvcpus
    allocated.memory += vm.hardware.memory_cpu
    allocated.storage += vm.hardware.disk_capacity
  }
  allocated.storage /= (1024**3)

  info("Already allocated resources: #{allocated.inspect}")
  return allocated
end

def extract_request(request)
  require 'fog'
  
  vms_in_request = request.get_option(:dialog)["dialog_vm_qty"].to_i
  flavor_id = request.get_option(:dialog)["dialog_vm_size"]
  flavor = $evm.vmdb('flavor').find(flavor_id)

  # get CPU in request
  cpus_in_flavor = flavor.cpus.to_i
  cores_per_cpu = flavor.cpu_cores.nil? ? 1 : flavor.cpu_cores.to_i
  total_cpus = vms_in_request * cpus_in_flavor * cores_per_cpu
  info("Total Requested Provisioning vCPUs: #{total_cpus}")
  
  # get memory in request
  memory_per_vm = flavor.memory / (1024**2)
  total_memory = vms_in_request * memory_per_vm
  info("Total Requested Provisioning Memory: %.2fMB" % total_memory)
  
  # get storage size
  ems = flavor.ext_management_system
  compute = Fog::Compute.new(:provider => ems.emstype,
                             :openstack_username => ems.authentication_userid,
                             :openstack_api_key => ems.authentication_password,
                             :openstack_auth_url => "http://#{ems.hostname}:#{ems.port}/v2.0/tokens",
                             :openstack_tenant => 'admin')
  storage_per_vm = compute.get_flavor_details(flavor.ems_ref).data[:body]['flavor']['disk'].to_i
  total_storage = storage_per_vm * vms_in_request
  info("Total Requested Provisioning Storage: %.2fGB" % total_storage)
  
  return Resources.new(total_cpus, total_memory, total_storage)
end

info("Automate Method started")

# Initialize Variables
quota_exceeded = false
prov = $evm.root['miq_request']
prov_resource = prov.resource
raise "Provisioning Request not found" if prov.nil? || prov_resource.nil?


# Get associated project info for quotas and allocations.
project = JSON.parse(prov.get_option(:dialog)["dialog_project"])
info("Project tag name: #{project['tag_name']} id: #{project['tag_id']}")
quotas = get_project_quotas(project['tag_name'])
allocated = get_project_allocations(project['tag_name'])

# Calculate available resources left.
available = quotas - allocated
info("Available resources for project: #{available.inspect}")

# Get requested resource levels.
request = extract_request(prov)
remaining_resource = available - request

# Initialize variables used
quota_exceeded = false
reason1      = nil
reason2      = nil
reason3      = nil

if remaining_resource.is_overutilized?
  info("Cannot proceed with provisioning request. Request exceeds available resources for project.")
  quota_exceeded = true
  if remaining_resource.cpu < 0
    reason1 = "Requested CPUs (#{request.cpu}) exceeds available CPUs (#{available.cpu})."
  end
  if remaining_resource.memory < 0
    reason2 = "Requested memory (#{request.memory}) exceeds available memory (#{available.memory})."
  end
  if remaining_resource.storage < 0
    reason3 = "Requested storage (#{request.storage}) exceeds available storage (#{available.storage})."
  end
end

######################################
#
# Update Message to Requester
#
######################################
    if quota_exceeded == true
  msg =  "Request failed for the following reasons: "
  msg += "(#{reason1}) " unless reason1.nil?
  msg += "(#{reason2}) " unless reason2.nil?
  msg += "(#{reason3}) " unless reason3.nil?
  prov_resource.set_message(msg)
  $evm.log("info", "Inspecting Messge:<#{msg}>")

  $evm.root['ae_result'] = 'error'
  $evm.object['reason'] = msg
end

info("Automate method ended")
