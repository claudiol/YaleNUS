#!/bin/sh
BUILDDIR=/tmp/Yale-NUS-`date +"%Y-%m-%d-%H-%M"`

rm -fR ${BUILDDIR}
mkdir -p ${BUILDDIR}/buttons
mkdir -p ${BUILDDIR}/service_catalogs
mkdir -p ${BUILDDIR}/dialogs
mkdir -p ${BUILDDIR}/roles
mkdir -p ${BUILDDIR}/tags

cd /var/www/miq/vmdb
echo -n "Exporting Service Dialogs ..."
rake rhconsulting:service_catalogs:export[${BUILDDIR}/service_catalogs]
echo "Done!"
echo -n "Exporting Dialogs ..."
rake rhconsulting:dialogs:export[${BUILDDIR}/dialogs]
echo "Done!"
echo -n "Exporting Roles..."
rake rhconsulting:roles:export[${BUILDDIR}/roles/roles.yml]
echo "Done!"
echo -n "Exporting Tags..."
rake rhconsulting:tags:export[${BUILDDIR}/tags/tags.yml]
echo "Done!"
echo -n "Exporting Buttons ..."
rake rhconsulting:buttons:export[${BUILDDIR}/buttons/buttons.yml]
echo "Done!"
