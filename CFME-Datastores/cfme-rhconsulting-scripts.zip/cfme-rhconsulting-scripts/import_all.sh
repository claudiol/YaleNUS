#!/bin/sh
BUILDDIR=/tmp/CFME-build

cd /var/www/miq/vmdb
#rake rhconsulting:service_catalogs:import[${BUILDDIR}/service_catalogs]
#rake rhconsulting:dialogs:import[${BUILDDIR}/dialogs]
#rake rhconsulting:roles:import[${BUILDDIR}/roles/roles.yml]
#rake rhconsulting:tags:import[${BUILDDIR}/tags/tags.yml]
rake rhconsulting:buttons:import[${BUILDDIR}/buttons/buttons.yml]
