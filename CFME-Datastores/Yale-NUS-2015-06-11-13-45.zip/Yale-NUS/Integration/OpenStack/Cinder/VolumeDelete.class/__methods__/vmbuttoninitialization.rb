###################################  
#  
# CloudForms Automate Method: VmButtonInitialization  
#  
# This method is used to initialize the instance attributes for volume
# deletion when called from a button on a VM.
#
# Dialog fields expected:
#   1. cinder_volume_id - OpenStack Cinder Volume Id
#
###################################  
  
###### TRACERS ######  
# Method for logging  
def log(level, message)  
  $evm.log(level, "#{message}")  
end  
  
def debug(message)  
  log(:debug, message)  
end  
  
def info(message)  
  log(:info, message)  
end  
  
def error(message)  
  log(:error, message)  
end  
  
def dump_root  
  log(:info, "Root:<$evm.root> Attributes - Begin")  
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }  
  log(:info, "Root:<$evm.root> Attributes - End")  
  log(:info, "")  
end  
  
def dump_attributes(object)  
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")  
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }  
  log(:info, "CUSTOM  End Attributes [object.attributes]")  
  log(:info, "")  
end  
###### TRACERS ######  
  
begin  
  
  info("Automate method started.")  
    
  # get the VM and EMS from the current context.
  vm = $evm.root['vm']
  ems = vm.ext_management_system
  info("VM name: #{ vm.name }")
  info("EMS name: #{ ems.name }")
  
  # fill in the instance attributes.
  $evm.object["cinder_volume_id"] = $evm.root["dialog_cinder_volume_id"]
  $evm.object["os_authentication_userid"] = ems.authentication_userid
  $evm.object["os_authentication_password"] = ems.authentication_password
  $evm.object["os_authentication_url"] = "http://#{ ems.hostname }:#{ ems.port }/v2.0/tokens"

  # show the values in the log.
  info("Initialized the following instance attributes:")
  info("	cinder_volume_id: #{ $evm.object["cinder_volume_id"] }")
  info("	os_authentication_userid: #{ $evm.object["os_authentication_userid"] }")
  info("	os_authentication_password: #{ $evm.object["os_authentication_password"] }")
  info("	os_authentication_url: #{ $evm.object["os_authentication_url"] }")

  info("Automate method ended.")
  
  exit MIQ_OK
  
end 
