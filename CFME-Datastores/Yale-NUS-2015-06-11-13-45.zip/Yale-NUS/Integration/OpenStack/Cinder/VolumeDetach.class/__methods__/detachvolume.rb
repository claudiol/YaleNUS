###################################
#
# CloudForms Automate Method: DetachVolume
#
# This method is used to detach a volume
# currently attached to an OpenStack Instance
#
###################################

###### TRACERS ######
# Method for logging
def log(level, message)
  $evm.log(level, "#{message}")
end

def debug(message)
  log(:debug, message)
end

def info(message)
  log(:info, message)
end

def error(message)
  log(:error, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

begin
  
  info("Automate method started.")
  
  require 'fog'
  
  # get the MIQ instance for the VM
  vm = $evm.vmdb(:vm).find($evm.object["vm_id"])

  # cinder volume ID
  cinder_volume_id = $evm.object["cinder_volume_id"]

  # Set up Fog connection to Openstack.
  os_user_id = $evm.object["os_authentication_userid"]
  os_password = $evm.object["os_authentication_password"]
  os_auth_url = $evm.object["os_authentication_url"]
  os_tenant = $evm.object["os_tenant"]
  info("Fog openstack_username: #{ os_user_id }, openstack_api_key: #{ os_password }, openstack_auth_url: #{ os_auth_url }, openstack_tenant: #{ os_tenant }")
  
  fog_conn = Fog::Compute.new({:provider => 'openstack',
                              :openstack_username => os_user_id,
                              :openstack_api_key => os_password,
                              :openstack_auth_url => os_auth_url,
                              :openstack_tenant => os_tenant})

  # get the VM that this volume is attached to.
  fog_vm = fog_conn.servers.get(vm.ems_ref)
  debug("Got Fog VM: #{ fog_vm.inspect }")
  
  fog_vm.detach_volume(cinder_volume_id)
  
  vol = fog_conn.volumes.get(cinder_volume_id)
  # Ensure that the Volume has really detached(if so, status will say 'available').
  retries = 0
  until vol.status == 'available' or retries >= $evm.object['retries'] do
    info("Volume status is not 'available'")
    sleep $evm.object['sleep']
    retries += 1
    vol.reload
    info("Retry #{ retries } of #{ $evm.object['retries'] }. Volume not yet fully detached (#{ vol.status }). Sleeping...")
  end

  # we exit with an error unless we know that the volume was detached successfully
  unless vol.status == 'available'
    error("Timeout while waiting for volume #{vol_id} to be available for attachment. Volume Status: #{ vol.status }")
    exit MIQ_ERROR
  end

  info("Volume successfully detached.")

  info("Automate method ended.")

  exit MIQ_OK
end
