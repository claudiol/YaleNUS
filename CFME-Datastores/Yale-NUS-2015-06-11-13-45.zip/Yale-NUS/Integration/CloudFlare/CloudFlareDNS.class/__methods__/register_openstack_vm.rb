#
# Method: register_openstack_vm
#
# This methd is used to register an OpenStack VM to the CloudFlareDNS service.
#
# Author: George Goh <george.goh@redhat.com>, Lester Claudio <lester@redhat.com>

# Load the aws-sdk
require "fog"
require "CloudFlareDNS"
require "json"


begin
  # Get provisioning object
  prov = $evm.root["miq_provision"]

  $evm.log("info", "OpenStack Post Provision: Provisioning ID:<#{prov.id}> Provision Request ID:<#{prov.miq_provision_request.id}> Provision Type: <#{prov.provision_type}>")

  vm = prov.vm
  ems = vm.ext_management_system
  os_tenant_name = $evm.vmdb(:CloudTenant).find(vm.cloud_tenant_id).name

  fog_conn = Fog::Compute.new({:provider => 'openstack',
                        :openstack_username => ems.authentication_userid,
                        :openstack_api_key => ems.authentication_password,
                        :openstack_auth_url => "http://#{ ems.hostname }:#{ ems.port }/v2.0/tokens",
                        :openstack_tenant => os_tenant_name})

  $evm.log("info", "Retrieving Fog VM")
  fog_vm = fog_conn.servers.get(vm.ems_ref)

  public_ip_address = fog_vm.public_ip_address
  all_ips = vm.ipaddresses.dup
  all_ips.delete(public_ip_address)
  private_ip_address = all_ips.first
  $evm.log(:info, "Public VM IP Address: #{ public_ip_address } Private VM IP Address: #{ private_ip_address }")
  
  # Get the domain from the State Machine attributes for YaleNUS
  dns_domain = $evm.object['domain']
  
  # Use the user given name for the instance
  dns_name = vm.name

  # Create the options hash to initialize the CloudFlareDNS instance
  options={}
  options[:tkn] = $evm.object['tkn']
  options[:email] = $evm.object['email']
  options[:zoneid] = $evm.object['zoneid']
  options[:apihost] = $evm.object['apihost']
  
  # Create a new CloudFlareDNS Instance
  cfdns = CloudFlareDNS.new(options)

  # Check Public IP address first ...
  unless public_ip_address.nil?
   # Let's create the public DNS record ...
   # Create the Add DNS Record request.
   # Add a DNS Record to CloudFlare Data we will be adding

    request_data = {}
  	request_data[:type] = "A"
  	request_data[:name] = dns_name + "." + dns_domain
  	request_data[:content] = public_ip_address
  	request_data[:ttl] = "120"
  
  	json_data = JSON.generate(request_data)
  	$evm.log(:info,  "Adding Public DNS Record #{json_data} to CloudFlare Service ...")
  	response = cfdns.add_cloudflare_record(json_data)

  	result = response['success']

  	if result
      	$evm.log(:info, "Added DNS Public record successfully to CloudFlare DNS Service for instance [#{vm.name}]")
  	else
   		$evm.log(:info, "Could not add Public DNS record successfully to CloudFlare DNS Service for instance [#{vm.name}]")
  	end
  end
  
  # Check Private IP address second ...
  unless private_ip_address.nil?
   # Let's create the public DNS record ...
   # Create the Add DNS Record request.
   # Add a DNS Record to CloudFlare Data we will be adding

    request_data = {}
  	request_data[:type] = "A"
  	request_data[:name] = dns_name + "-int." + dns_domain
    request_data[:content] = private_ip_address
  	request_data[:ttl] = "120"
  
  	json_data = JSON.generate(request_data)
    $evm.log(:info,  "Adding Private DNS Record #{json_data} to CloudFlare Service ...")
  	response = cfdns.add_cloudflare_record(json_data)

  	result = response['success']

  	if result
      $evm.log(:info, "Added DNS Private record successfully to CloudFlare DNS Service for instance [#{vm.name}]")
  	else
      $evm.log(:info, "Could not add Private DNS record successfully to CloudFlare DNS Service for instance [#{vm.name}]")
  	end
  end
  
  
  
  
  
  exit MIQ_OK
    
rescue => ex
    $evm.log(:info, "EXCEPTION #{ex.message}")
    exit MIQ_ABORT
end
