#
# Description: Populate a dynamic drop down list with available images
#

###### TRACERS ######
# Method for logging
def log(level, message)
  @method = 'populateImageTypes'
  $evm.log(level, "#{@method} - #{message}")
end

def info(message)
  log(:info, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######


info("populateImageTypes Automate Method Started")

droplist = $evm.object

droplist["data_type"] = "String"
droplist["required"] = "true"

dump_root

# Retrieve ext_management_system based on the info we get from the service template
ems = $evm.vmdb("ems_openstack").first # assuming only one of each provider type.

# Find all templates associated with this ID
templates = $evm.vmdb(:template_cloud).find_all_by_ems_id(ems.id)
default_value = templates[0].id.to_s
$evm.log("info", "Default value: #{ default_value }")


# Create droplist values
option_hash = {}
templates.each { |template|
  if template.publicly_available
    key = template.id.to_s
    value = template.name
    $evm.log("debug", "Adding '#{ key }':'#{ value }' to droplist values")
    option_hash[key] = value
  end
}
info("Generated droplist options: #{ option_hash }")
droplist["values"] = option_hash
#droplist["default_value"] = default_value

info("populateImageTypes Automate Method Ended")

exit MIQ_OK
