#
# Description: Populate a dynamic drop down list with available AWS regions
#

###### TRACERS ######
# Method for logging
def log(level, message)
  @method = 'populateProjects'
  $evm.log(level, "#{@method} - #{message}")
end

def info(message)
  log(:info, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

info("populateProjects Automate Method Started")

require 'json'

cfuser = $evm.root["user"]
info("User id: #{$evm.root["user"][:userid]}")

droplist = $evm.object

droplist["data_type"] = "String"
droplist["required"] = "true"

# Retrieve project tags for the user
project_tag_lbls = cfuser.tags.select { |tag| tag.starts_with? 'projects/' }
info("List of projects associated with this user #{ project_tag_lbls }")

if project_tag_lbls.empty?
  droplist["values"] = { "nil" => "User has no projects" }
  exit MIQ_ERROR  
end

classification = $evm.vmdb('classification')

# create droplist values
option_hash = {}
project_tag_lbls.each { |lbl|
  tag = classification.find_by_name(lbl)
  key = JSON.generate( {:tag_name => lbl, :tag_id => tag.id.to_s} )
  value = tag.description.to_s
  info("Adding '#{ key }':'#{ value }' to droplist values")
  option_hash[key] = value
}

info("Generated droplist options: #{ option_hash }")
droplist["values"] = option_hash

#droplist["default_value"] = option_hash.keys[-1]

info("populateProjects Automate Method Ended")

exit MIQ_OK
