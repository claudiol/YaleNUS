###################################
#
# CloudForms Automate Method: populateAttachedCinderVolumes
#
# This method is used to populate a drop-down list with a list of volumes 
# currently attached to an OpenStack Instance
#
###################################

###### TRACERS ######
# Method for logging
def log(level, message)
  @method = 'populateAttachedCinderVolumes'
  $evm.log(level, "#{@method} - #{message}")
end

def info(message)
  log(:info, message)
end

def error(message)
  log(:error, message)
end

def debug(message)
  log(:debug, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

begin
  
  require 'fog'

  info("Automate method started.")
  
  vm = $evm.root['vm']
  ems = vm.ext_management_system
  info("VM name: #{ vm.name }")
  info("EMS name: #{ ems.name }")

  # Set up Fog connection to Openstack.
  os_user_id = ems.authentication_userid
  os_password = ems.authentication_password
  os_auth_url = "http://#{ ems.hostname }:#{ ems.port }/v2.0/tokens"
  os_tenant = ems.cloud_tenants.select { |t| t.id == vm.cloud_tenant_id }.first.name
  info("Fog provider: #{ ems.emstype }, openstack_username: #{ os_user_id }, openstack_api_key: #{ os_password }, openstack_auth_url: #{ os_auth_url }, openstack_tenant: #{ os_tenant }")
  
  compute = Fog::Compute.new({:provider => ems.emstype,
                              :openstack_username => os_user_id,
                              :openstack_api_key => os_password,
                              :openstack_auth_url => os_auth_url,
                              :openstack_tenant => os_tenant})

  fog_vm = compute.servers.get(vm.ems_ref)
  info("Got Fog VM: #{ fog_vm.inspect }")
  
  option_hash = {}
  fog_vm.volume_attachments.each { |vol_attachment|
    key = vol_attachment['volumeId']
    value = vol_attachment['device']
    debug("Adding '#{ key }:#{ value }' to droplist values")
    option_hash[key] = value
  }
  
  info("Generated droplist options: #{ option_hash }")

  droplist = $evm.object
  droplist["data_type"] = "String"
  droplist["required"] = "true"
  droplist["values"] = option_hash
  
  info("Automate method ended.")

  exit MIQ_OK
end
