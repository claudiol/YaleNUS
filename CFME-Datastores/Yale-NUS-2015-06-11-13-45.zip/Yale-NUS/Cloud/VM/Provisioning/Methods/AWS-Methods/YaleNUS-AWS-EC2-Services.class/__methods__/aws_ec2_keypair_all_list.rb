###################################
#
# CloudForms Automate Method: aws_ec2_keypair_all_list
#
# This method is used to search for all Keypairs that are owned by a user in all allowed regions
#
###################################
#
# Method for logging
def log(level, message)
  @method = 'aws_ec2_keypair_all_list'
  $evm.log(level, "#{@method} - #{message}")
end
#
log(:info, "===== AWS List All Keypairs in All Available Regions ==== Automate Method Started")
#            Method Code Goes here
#
# Load the aws-sdk
require "aws-sdk"


begin
  access_key_id = nil
  secret_access_key = nil

  dialog_field = $evm.object

  # Dynamic list to add values to the dialog dynamic list ...
  list = {}

  # Count of regions ...
  count = 0

  # Save first entry and make it the default region
  first = nil

  #####RBAC sample, setting the filter mode

  this_user = $evm.root['user'].userid.downcase
  log(:info, "this_user : #{this_user.inspect}")
  #AWS doesn't like underscores, dashes or spaces so strip
  this_user_group = $evm.root['user'].ldap_group.downcase.gsub(/[\W+]|[_]/,'')
  log(:info, "this_user_group (cleaned of underscores): #{this_user_group.inspect}")


  filter_user = 'none' # values user, group, none

  if this_user_group  == 'evmgroupsuperadministrator' #remember that the naming removes any underscores, always lower
    filter_user = 'none'
  elsif this_user_group.nil?
    filter_user = 'user'
  elsif this_user_group == 'cloudforms'  #remember to tag all lower case, naming stripped with the REGEX
    filter_user = 'user'
  else
    filter_user = 'group'
  end

  # Get the Amazon authentication credentials...
  ems = $evm.vmdb(:ems_amazon).first
  
  if ems.nil?
    # Get the values from the schema ...
    access_key_id ||= $evm.object['access_key_id']
    secret_access_key = $evm.object.decrypt('secret_access_key')
  else
    access_key_id ||= ems.authentication_userid
    secret_access_key = ems.authentication_password
  end
  
  
  r = allowed_regions = ems.provider_region
  
  #allowed_regions = $evm.object['allowed_regions']
  #allowed_regions = allowed_regions.split(",").each {|t| t.strip!}

  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  log(:info, "+++++++++++++++++++ Dump of Allowed Regions : #{allowed_regions} +++++++++++++++++++++++")

  # Go through all regions
  #allowed_regions.each do |r|
    log(:info, "<<<<<<<<<================>>>>>>>>> Processing region #{r}  <<<<<<<<<<<<<=================>>>>>>>>>>>>>")

    log(:info, '   ================ Creating EC2 object =================')
    ec2 = AWS::EC2.new(:region => r)

    ec2.key_pairs.each do |k|
      log(:info,"#{k.inspect}")

      if filter_user =='user'
        if k.name.downcase.include? this_user
          $evm.log("info", "Keypair (added) : #{k.name} ")
          list[k.name]  = "#{k.name}"
        else
          $evm.log("info", "Keypair (skipped, not user): #{k.name} ")
        end
      elsif filter_user =='group'
        if k.name.downcase.include? this_user_group
          $evm.log("info", "Keypair (added) : #{k.name} ")
          list[k.name]  = "#{k.name}"
        else
          $evm.log("info", "Keypair (skipped, not group): #{k.name} ")
        end
      else #should only fall through for Admin - group EvmGroup-super_administrator
        $evm.log("info", "Keypair (added) : #{k.name} ")
        list[k.name]  = "#{k.name}"
      end

    end
  #end

  list[""] = ""

  log(:info, "LIST: #{list.inspect} ")

  # sort_by: value / description / none
  $evm.object["sort_by"] = "description"
  # sort_order: ascending / descending
  $evm.object["sort_order"] = "ascending"
  # data_type: string / integer
  $evm.object["data_type"] = "string"
  # required: true / false
  $evm.object["required"] = "true"
  # Add list to dialog dynamic list ...
  $evm.object["values"] = list


  # Make the first entry the default value
  $evm.object["default_value"] = first


  #log(:info, "Dialog Inspect: #{$evm.object.inspect}")

  log(:info, "====== AWS List All Keypairs in All Available Regions =====  Automate Method Ended")
  exit MIQ_OK

rescue => exception
  log(:info, "====== AWS List All Keypairs in All Available Regions =====")
  log(:info, exception.message)
end
