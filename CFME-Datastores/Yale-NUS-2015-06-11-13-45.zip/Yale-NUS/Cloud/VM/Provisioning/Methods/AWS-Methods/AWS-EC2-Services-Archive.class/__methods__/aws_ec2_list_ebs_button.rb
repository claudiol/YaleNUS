###################################
#
# CloudForms Automate Method: list_all_ebs
#
# This method is used to list all EBS Volumes
#
###################################
# Method for logging
def log(level, message)
  @method = 'list_all_ebs'
  $evm.log(level, "#{@method} - #{message}")
end

log(:info, "CloudForms Automate Method Started")

require 'aws-sdk'

# Get provisioning object

begin

  vm = $evm.root['vm']
  #log(:info, " VM Info : #{vm.inspect}")

  ems = vm.ext_management_system

  region = ems.hostname

  # Get the Amazon authentication credentials...
  access_key_id ||= ems.authentication_userid
  secret_access_key = ems.authentication_password

  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  # Start Here
  log(:info, "Selected Region: #{region}")

  #
  ec2 = AWS::EC2.new( :region => region )


  # Create some local variables ...

  # Dynamic list to add values to the dialog dynamic list ...
  list = {}

  # Count of regions ...
  count = 0

  # Save first entry and make it the default region
  first = nil

  # Go through all regions returned from EC2 and add them to list

  ec2.volumes.each do |v|
    count += 1
    if count == 1
      first = v.id
    end
    log(:info, "EBS: #{v.id} ")
    list[v.id]  = "#{v.id}"
  end

  list[""] = ""

  log(:info, "LIST: #{list.inspect} ")

  # sort_by: value / description / none
  $evm.object["sort_by"] = "description"
  # sort_order: ascending / descending
  $evm.object["sort_order"] = "ascending"
  # data_type: string / integer
  $evm.object["data_type"] = "string"
  # required: true / false
  $evm.object["required"] = "true"
  # Add list to dialog dynamic list ...
  $evm.object["values"] = list


  # Make the first entry the default value
  $evm.object["default_value"] = first

  # ec2.volumes.each do |v|
  #   v.id



  ############
  # Exit method
  #
  log(:info, "CloudForms Automate Method Ended")
  exit MIQ_OK
end
