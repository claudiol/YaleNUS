###################################
#
# CloudForms Automate Method: aws_ec2_ebs_list_attachments
#
# This method is used to list all EBS Volume attachments for an instance
#
###################################
# Method for logging
def log(level, message)
  @method = 'aws_ec2_ebs_list_attachments'
  $evm.log(level, "#{@method} - #{message}")
end

log(:info, "CloudForms Automate Method Started")

require 'aws-sdk'

# Get provisioning object

begin

  vm = $evm.root['vm']

  ems = vm.ext_management_system

  region = ems.provider_region

  # Get the Amazon authentication credentials...
  access_key_id ||= ems.authentication_userid
  secret_access_key = ems.authentication_password

  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  # Start Here
  #
  log(:info, "Accessing region: #{region}")
  
  ec2 = AWS::EC2.new( :region => region )


  # Create some local variables ...

  # Dynamic list to add values to the dialog dynamic list ...
  list = {}
  #
  # Save first entry and make it the default region
  first = nil

  i = ec2.instances[vm.uid_ems]
  
  log(:info, "Found Instance: #{i}")
  
  block_devices = i.block_devices
  
  log(:info, "Block Devices: #{block_devices}")
  
  i.block_devices.each do |b|
    #ap b.inspect
    #ap b[:ebs][:volume_id]
    #ap b[:device_name].gsub(/[0-9]/,'')
    device_list = ["/dev/sda", "/dev/sdb", "/dev/sdc", "/dev/sdd", "/dev/sde"]
    #ap device_list.any? { |s| s.include?(b[:device_name].gsub(/[0-9]/,'')) }
    unless device_list.any? { |s| s.include?(b[:device_name].gsub(/[0-9]/,'')) }
      # Left is the display string and the right is what is passed back to cfme
      volume = ec2.volumes.each do |v|
        if v.id != b[:ebs][:volume_id]
          # list["#{b[:ebs][:volume_id]}|#{b[:device_name]}"]  = b[:ebs][:volume_id]
        else
          tags_hash = v.tags.to_h
          name = tags_hash["Name"]
          list["#{b[:ebs][:volume_id]}|#{b[:device_name]}|#{name}"]  = b[:ebs][:volume_id]
        end
      end
    end
  end

  # i.block_devices.each do |b|
  #   #ap b[:ebs][:volume_id]
  #   #ap b[:device_name].gsub(/[0-9]/,'')
  #   device_list = ["/dev/sda", "/dev/sdb", "/dev/sdc", "/dev/sdd", "/dev/sde"]
  #   #ap device_list.any? { |s| s.include?(b[:device_name].gsub(/[0-9]/,'')) }
  #   unless device_list.any? { |s| s.include?(b[:device_name].gsub(/[0-9]/,'')) }
  #     # Left is the display string and the right is what is passed back to cfme
  #     list["#{b[:ebs][:volume_id]}|#{b[:device_name]}"]  = b[:ebs][:volume_id]
  #   end
  # end

  list[""] = ""

  log(:info, "LIST: #{list.inspect} ")

  # sort_by: value / description / none
  $evm.object["sort_by"] = "description"
  # sort_order: ascending / descending
  $evm.object["sort_order"] = "ascending"
  # data_type: string / integer
  $evm.object["data_type"] = "string"
  # required: true / false
  $evm.object["required"] = "true"
  # Add list to dialog dynamic list ...
  $evm.object["values"] = list


  # Make the first entry the default value
  $evm.object["default_value"] = first
  # # Count of regions ...
  # count = 0
  #
  # # Save first entry and make it the default region
  # first = nil

  # Go through all regions returned from EC2 and add them to list

  # ec2.volumes.each do |v|
  #   v.attachments.each do |a|
  #     instance_id = a.instance.id
  #     if instance_id == vm_id
  #       log(:info, "++++++ VM Name Matches : #{name} +++++++++")
  #     end
  #   end
  #   count += 1
  #   if count == 1
  #     first = v.id
  #   end
  #   log(:info, "EBS: #{v.id} ")
  #   list[v.id]  = "#{v.id}"
  # end
  #
  # list[""] = ""
  #
  # log(:info, "LIST: #{list.inspect} ")
  #
  # # sort_by: value / description / none
  # $evm.object["sort_by"] = "description"
  # # sort_order: ascending / descending
  # $evm.object["sort_order"] = "ascending"
  # # data_type: string / integer
  # $evm.object["data_type"] = "string"
  # # required: true / false
  # $evm.object["required"] = "true"
  # # Add list to dialog dynamic list ...
  # $evm.object["values"] = list
  #
  #
  # # Make the first entry the default value
  # $evm.object["default_value"] = first

  # ec2.volumes.each do |v|
  #   v.id



  ############
  # Exit method
  #
  log(:info, "CloudForms Automate Method Ended")
  exit MIQ_OK
end
