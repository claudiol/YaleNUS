###################################
#
# CloudForms Automate Method: create_attach_ebs_volume_button
#
# This method is used to create a AWS EC2 EBS Volume via button
#
###################################
# Method for logging
def log(level, message)
  @method = 'create_attach_ebs_volume_button'
  $evm.log(level, "#{@method} - #{message}")
end

log(:info, "CloudForms Automate Method Started")

require 'aws-sdk'
dialog_field = $evm.object

# Get provisioning object

begin

  vm = $evm.root['vm']
  #log(:info, " VM Info : #{vm.inspect}")

  ems = vm.ext_management_system

  region = ems.provider_region

  $evm.log("info", "--------------calculate_ebs_name started------------------")
  # this creates an ELB name that follows the rules below
  # max length is 32 chars, all lower case, no underscores or dashes except those as part of composition
  # pattern of userid-group name limited-name passed in
  # regex used: /[\W+]|[_]/  Strips all non word characters and underscores (underscore is part of /W)
  # length of the group portion of the name is defined below
  group_length_limit = 15
  my_user = $evm.root['user']

  $evm.log("info", "userid ===> #{my_user.userid}")
  $evm.log("info", "group membership ===> #{my_user.miq_group.description}")

  cleaned_group = my_user.miq_group.description.downcase.gsub(/[\W+]|[_]/, '').first(group_length_limit)

  $evm.log("info", "user group normalized (15 chars) ===> #{cleaned_group}")

  # Get the name of the ELB name from the request ... validate_ELB_name adds it

  vol_name = $evm.root.attributes['dialog_aws_ebs_volume_name']
  clean_name = vol_name.downcase.gsub(/[\W+]|[_]/, '')
  $evm.log("info", "cleaned passed name ===> #{clean_name}")

  cleaned_ebs = "#{my_user.userid}-#{cleaned_group}-#{clean_name}".first(32)
  ebs_name = cleaned_ebs

  $evm.log("info", "Fully crafted name (32 char max, AWS limit) ===> #{cleaned_ebs}")
  $evm.log("info", "--------------calculate_elb_name ended------------------")

  # Addiong the user info and downcasing it
  user = $evm.root['user'].userid.downcase

  #AWS doesn't like underscores, dashes or spaces so strip for group
  user_group = $evm.root['user'].ldap_group.downcase.gsub(/[\W+]|[_]/,'')

  # Get the Amazon authentication credentials...
  access_key_id ||= ems.authentication_userid
  secret_access_key = ems.authentication_password

  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )


  # Get volume name from the dialog
  # vol_name = $evm.root.attributes['dialog_aws_ebs_volume_name']
   log(:info, "++++++++++++++++++ Volume Name : #{ebs_name} +++++++++++++++++++++++++")


  # Get the EBS size
  ebs_size = $evm.root.attributes['dialog_ebs_size'].to_i

  log(:info, " +++++++++++++++++ EBS Size : #{ebs_size.to_i} ++++++++++++++")


  # Start Here

  ec2 = AWS::EC2.new( :region => region  )

  i = ec2.instances["#{vm.uid_ems}"]
  availability_zone = i.availability_zone

  # Retreive the device name from the dialog (ex /dev/sdf)
  selected_device_name = $evm.root.attributes['dialog_ebs_device_list']

  #log(:info, "+++++++++++++++ Selected Region: #{region} +++++++++++++++++++++++++")

  #Set Availability Zone

  #log(:info, "+++++++++++++++ Selected Availability Zone : #{availability_zone} ++++++++++++++++++")

  #log(:info, "+++++++++++++++ User Name : #{user} ++++++++++++++++++++++")
  #log(:info, "+++++++++++++++ Group Name : #{user_group} +++++++++++++++++++")

  volume = ec2.volumes.create(:size => ebs_size,
                              :availability_zone => availability_zone)
  sleep 1 until volume.status != :creating

  # Now Tag the newly created volume from the username/groupid and volume name
  ec2.volumes["#{volume.id}"].tags["userid"] = "#{user}"
  ec2.volumes["#{volume.id}"].tags["usergroup"] = "#{user_group}"
  ec2.volumes["#{volume.id}"].tags["Name"] = "#{vol_name}"

  # Now attach the newly created volume to the current instance
  attachment = volume.attach_to(ec2.instances[vm.uid_ems], "#{selected_device_name}")
  sleep 1 until attachment.status != :attaching
  log(:info, "+++++++++++++++++++ Attached #{attachment} to #{i} with device #{selected_device_name} ++++++++++++++++++++++")

  vars = Hash.new
  vars[:type] = "create_attach_ebs_volume"
  vars[:action] = "Created"
  vars[:service_name] = "AWS EBS"
  vars[:vol_name] = vol_name
  vars[:selected_device_name] = selected_device_name
  vars[:vm_name] = vm['name']

  require 'json'
  require 'uri'
  args = "payload=#{vars.to_json}"
  args = URI.escape(args)
  $evm.log("info", "============== vars: #{vars.inspect}")
  $evm.log("info", "============== args: #{args.inspect}")
  $evm.instantiate("/Yale/Methods/Emails/Email_Owner?#{args}")

  ############
  # Exit method
  #
  log(:info, "CloudForms Automate Method Ended")
  exit MIQ_OK
end

