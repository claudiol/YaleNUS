#            Automate Method
#
$evm.log("info", "======== VALIDATE S3 BUCKET ======== Automate Method Started")
#
#            Method Code Goes here
#
require 'aws-sdk'

begin
   access_key_id = nil
   secret_access_key = nil
   # Get the Amazon authentication credentials...
   access_key_id ||= $evm.object['access_key_id']
   secret_access_key = $evm.object.decrypt('secret_access_key')


  $evm.log("info", "ID: #{access_key_id} Secret: #{secret_access_key}")

   AWS.config(
      :access_key_id => access_key_id,
  	:secret_access_key => secret_access_key
   )
    
   ems = $evm.vmdb('ems')

   $evm.log("info", "EMS #{ems.inspect}")

   amazon = ems.first

   $evm.log("info", "EMS Fist #{amazon.inspect}")

   # Get Prefix ....
   prefix = $evm.root['bucket_name_prefix']
   # Get the name of the bucket name from the dialog\
   bucket_name = $evm.root['dialog_bucket_name']
   # Retrieve the region from the dialog
   region      = $evm.root['dialog_aws_region']

   # Get Email ...
   email = $evm.root['dialog_email_address']

   if email != nil
      $evm.object['email_address'] = "#{email}"
   end

   # Get current provisioning status
   task = $evm.root['service_template_provision_task']

   # Retrieve the GUID to make it really unique
   guid = "#{task.miq_request_id}"

   # Create the basic S3 object
   s3_instance = AWS::S3.new(:region => region)


   # Concatenate the bucket name
   new_bucket_name = "#{prefix}#{bucket_name}-#{guid}"

   # Check for Upper Case letters in the name or underscore
   if new_bucket_name.match(/[A-Z]/) || new_bucket_name.match('_')
      raise "S3 bucket name: #{new_bucket_name} contains capital letters.  S3 bucket name must not contain capital letters or undersocres"
   end


   # Load up the 'bucket' we want to store things in
   bucket = s3_instance.buckets[new_bucket_name]
   # If the bucket doesn't exist, create it
   begin
      unless bucket.exists?
	     $evm.log("info", "AWS S3 bucket #{new_bucket_name} name is unique for region #{region} ...")
         $evm.object['bucket_name'] = "#{new_bucket_name}"
         $evm.object['bucket_aws_region'] = "#{region}"
	  else
		 $evm.log("info", "Bucket #{new_bucket_name} already exists! Aborting!")
	     exit MIQ_ABORT
	  end
   rescue => ex
        $evm.log("info", "======  AWS Exception =====")
        $evm.log("info", ex.message)
        exit MIQ_ABORT
   end
rescue => ex
     $evm.log("info", "======  AWS Exception =====")
     $evm.log("info", ex.message)
     exit MIQ_ABORT
end
#
$evm.log("info", "======== VALIDATE S3 BUCKET ======== Automate Method Ended")
exit MIQ_OK
