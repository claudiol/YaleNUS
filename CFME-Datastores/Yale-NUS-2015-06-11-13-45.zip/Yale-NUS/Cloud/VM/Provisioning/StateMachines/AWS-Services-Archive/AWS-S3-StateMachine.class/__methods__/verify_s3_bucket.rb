#            Automate Method
#
$evm.log("info", "======== VERIFY S3 BUCKET ======== Automate Method Started")
#
#            Method Code Goes here
#
require 'aws-sdk'

begin
   access_key_id = nil
   secret_access_key = nil
  # Get the Amazon authentication credentials...
   access_key_id ||= $evm.object['access_key_id']
   secret_access_key = $evm.object.decrypt('secret_access_key')

   AWS.config(
      :access_key_id => access_key_id,
  	:secret_access_key => secret_access_key
   )

   # Get the name of the bucket name from the dialog\
   bucket_name = $evm.root['bucket_name']
   # Retrieve the region from the dialog
   region      = $evm.root['bucket_aws_region']

   # Create the basic S3 object
   s3_instance = AWS::S3.new(:region => region)


   bucket = s3_instance.buckets[bucket_name]
   # If the bucket doesn't exist, create it
   begin
      unless bucket.exists?
		 raise "Bucket [#{bucket_name}] was not created! Aborting!"
	  else
	     $evm.log("info", "AWS S3 bucket #{bucket_name} exists and created successfully in region #{region} ...")
	  end
   rescue => ex
        $evm.log("info", "======  AWS Exception =====")
        $evm.log("info", ex.message)
        $evm.log("info", "======  AWS Exception =====")
        exit MIQ_ABORT
   end
rescue => ex
     $evm.log("info", "======  AWS Exception =====")
     $evm.log("info", ex.message)
     $evm.log("info", "======  AWS Exception =====")
     exit MIQ_ABORT
end

#
#
#
$evm.log("info", "======== VERIFY S3 BUCKET ======== Automate Method Ended")
exit MIQ_OK
