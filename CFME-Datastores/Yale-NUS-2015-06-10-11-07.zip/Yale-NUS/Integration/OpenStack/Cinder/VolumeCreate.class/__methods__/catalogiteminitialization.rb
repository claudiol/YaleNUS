###################################  
#  
# CloudForms Automate Method: CatalogItemInitialization  
#  
# This method is used to initialize the instance attributes for volume
# deletion when called from the Catalog Item context.
#
# Dialog fields expected:
#   1. cinder_volume_id - OpenStack Cinder Volume Id
#
# Dialog fields optional:
#   1. ems_id - The ID for the ext_management_system that the volume belongs to.
#               If ems_id is not supplied, then we take the first ems_id returned
#               from VMDB.
###################################  
  
###### TRACERS ######  
# Method for logging  
def log(level, message)  
  $evm.log(level, "#{message}")  
end  
  
def debug(message)  
  log(:debug, message)  
end  
  
def info(message)  
  log(:info, message)  
end  
  
def error(message)  
  log(:error, message)  
end  
  
def dump_root  
  log(:info, "Root:<$evm.root> Attributes - Begin")  
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }  
  log(:info, "Root:<$evm.root> Attributes - End")  
  log(:info, "")  
end  
  
def dump_attributes(object)  
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")  
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }  
  log(:info, "CUSTOM  End Attributes [object.attributes]")  
  log(:info, "")  
end  
###### TRACERS ######  
  
begin  
  
  info("Automate method started.")  
    
  # if the dialog doesn't specify an EMS id, then we assume the first OpenStack EMS.
  if $evm.object.attributes.key? 'dialog_ems_id'
    ems = $evm.vmdb(:ems_openstack).find($evm.object['dialog_ems_id'])
  else
    ems = $evm.vmdb(:ems_openstack).first
  end
  
  # fill in the instance attributes.
  $evm.object["cinder_volume_name"] = $evm.root["dialog_cinder_volume_name"]
  $evm.object["cinder_volume_description"] = $evm.root["dialog_cinder_volume_description"]
  $evm.object["cinder_volume_size"] = $evm.root["dialog_cinder_volume_size"]
  $evm.object["os_authentication_userid"] = ems.authentication_userid
  $evm.object["os_authentication_password"] = ems.authentication_password
  $evm.object["os_authentication_url"] = "http://#{ ems.hostname }:#{ ems.port }/v2.0/tokens"

  # show the values in the log.
  info("Initialized the following instance attributes:")
  info("	cinder_volume_az: #{ $evm.object["cinder_volume_az"] }")
  info("	cinder_volume_name: #{ $evm.object["cinder_volume_name"] }")
  info("	cinder_volume_description: #{ $evm.object["cinder_volume_description"] }")
  info("	cinder_volume_size: #{ $evm.object["cinder_volume_size"] }")
  info("	os_authentication_userid: #{ $evm.object["os_authentication_userid"] }")
  info("	os_authentication_password: #{ $evm.object["os_authentication_password"] }")
  info("	os_authentication_url: #{ $evm.object["os_authentication_url"] }")
  exit MIQ_OK
  
end 
