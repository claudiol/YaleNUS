#
# Description: This method is used to Assign a Public IP to an OpenStack Instance
#

###### TRACERS ######
# Method for logging
def log(level, message)
  $evm.log(level, "#{message}")
end

def info(message)
  log(:info, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

info("Automate Method Started")

require 'fog'


def has_public_ip(fog_vm)
  # assumes only one network interface.
  addresses = fog_vm.addresses.values[0]
  floating_ips = addresses.select { |address| address['OS-EXT-TYPE:type']=='floating' }
  if floating_ips.length > 0
    return true
  end
  return false
end

begin

  require 'fog'
  
  # get what we need from the EVM object attributes.
  vm_id = $evm.object["vm_id"]
  floating_ip_pool_name = $evm.object["floating_ip_pool_name"]
  
  # VM attributes
  vm = $evm.vmdb(:vm).find(vm_id)
  
  # Set up Fog connection to Openstack.
  os_user_id = $evm.object["os_authentication_userid"]
  os_password = $evm.object["os_authentication_password"]
  os_auth_url = $evm.object["os_authentication_url"]
  os_tenant = $evm.object["os_tenant"]
  info("Fog openstack_username: #{ os_user_id }, openstack_api_key: #{ os_password }, openstack_auth_url: #{ os_auth_url }, openstack_tenant: #{ os_tenant }")
  
  fog_conn = Fog::Compute.new({:provider => 'openstack',
                              :openstack_username => os_user_id,
                              :openstack_api_key => os_password,
                              :openstack_auth_url => os_auth_url,
                              :openstack_tenant => os_tenant})

  # Get the VM in Fog and attach the Floating IP.
  fog_vm = fog_conn.servers.select { |s| s.id == vm.uid_ems }.first

  if has_public_ip(fog_vm)
    info("VM already has a public IP!")
    exit MIQ_ABORT
  end

  # Get an unattached floating IP or create one if all are attached.
  info("Check for unassigned floating IP in pool '#{ floating_ip_pool_name }'.")
  fog_floating_ip = fog_conn.addresses.select { |a| a.instance_id==nil && a.pool==floating_ip_pool_name}.first
  if fog_floating_ip == nil
    info("No unassigned floating IPs in pool '#{ floating_ip_pool_name }'. Getting a new floating IP to assign")
    # exception handling req here if not able to allocate address.
    begin
      response = fog_conn.allocate_address(floating_ip_pool_name)
      fog_floating_ip = fog_conn.addresses.get(response.body['floating_ip']['id'])
    rescue
      exit MIQ_ABORT
    end
  end

  info("Associating public IP with instance.")
  fog_vm.associate_address(fog_floating_ip.ip)

  # After association, refresh VMDB's info on the VM
  vm.refresh
  info("Public IP association done.")

  info("Automate Method Ended")

  exit MIQ_OK
end
