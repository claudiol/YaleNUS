#
# Method: register_amazon_vm
#
# This methd is used to register an Amazon VM to the CloudFlareDNS service.
#
# Author: Lester Claudio <lester@redhat.com>

# Load the aws-sdk
require "aws-sdk"
require "CloudFlareDNS"
require "json"


begin
  # Get provisioning object
  prov = $evm.root["miq_provision"]

  $evm.log("info", "Amazon Post Provision: Provisioning ID:<#{prov.id}> Provision Request ID:<#{prov.miq_provision_request.id}> Provision Type: <#{prov.provision_type}>")

  vm = prov.vm
  ems = $evm.vmdb(:ems_amazon).first # vm.ext_management_system

  $evm.log(:info,  "Retrieved ems and vm references ...")

  # Now let's go to AWS and get the ipaddress information for the instance
  region = ems.provider_region
  access_key_id   = ems.authentication_userid
  secret_access_key = ems.authentication_password

  $evm.log(:info,  "Calling AWS Config...")
  AWS.config(
    :access_key_id => access_key_id,
    :secret_access_key => secret_access_key
  )
  
  default_region = ems.provider_region
   
  $evm.log(:info,  "Creating EC2 Object ...")
  # Create a basic EC2 object
  ec2_instance = AWS::EC2.new( :region => default_region )
  
  # Get the instance id for the AWS Instance
  instance_name = vm.uid_ems
  
  $evm.log(:info,  "AWS Instance name = #{instance_name} ...")
  if instance_name.nil?
    $evm.log(:info, "Could not retrieve instance name from VM object")
    exit MIQ_ABORT
  end

  aws_instance = ec2_instance.instances[instance_name]
  
  $evm.log(:info,  "AWS Instance name is #{aws_instance} ...")
  
  #
  # In AWS you can have a public ipaddress if your subnet isconfigured for auto-assign
  # and a private ip address.  We are going to register both with CloudFlare DNS service.
  # For the private ip address the naming convention will be:
  # <hostname>-int.aws.yale-nus.edu.sg
  # For the public IP address it will be:
  # <hostname>.aws.yale-nus.edu.sg
  #
  # 
  
  # Let's get our public facing IP address first. If nil we will not register it with CloudFlareDNS.
 
  ip_address = aws_instance.ip_address
  
  if ip_address.nil?
    $evm.log(:info,  "No AWS Public IP Address for #{aws_instance} ...")
  else
    $evm.log(:info,  "AWS Instance [#{aws_instance}] Public IP Address is #{ip_address} ...")
  end
  
  # Let's get our private IP address. If nil we will not register it with CloudFlareDNS.
 
  private_ip_address = aws_instance.private_ip_address
  
  if private_ip_address.nil?
    $evm.log(:info,  "No AWS Private IP Address for  #{aws_instance} ...")
  else
    $evm.log(:info,  "AWS Instance [#{aws_instance}] has Private IP Address is #{private_ip_address} ...")
  end
  
  # Get the domain from the State Machine attributes for YaleNUS
  dns_domain = $evm.object['domain']
  
  # Use the user given name for the instance
  dns_name = vm.name

  # Create the options hash to initialize the CloudFlareDNS instance
  options={}
  #options[:config_file] = 'cloudflare-config.yaml'
  options[:tkn] = $evm.object['tkn']
  options[:email] = $evm.object['email']
  options[:zoneid] = $evm.object['zoneid']
  options[:apihost] = $evm.object['apihost']
  
  # Create a new CloudFlareDNS Instance
  cfdns = CloudFlareDNS.new(options)

  # Check Public IP address first ...
  unless ip_address.nil?
   # Let's create the public DNS record ...
   # Create the Add DNS Record request.
   # Add a DNS Record to CloudFlare Data we will be adding

    request_data = {}
  	request_data[:type] = "A"
  	request_data[:name] = dns_name + "." + dns_domain
  	request_data[:content] = ip_address
  	request_data[:ttl] = "120"
  
  	json_data = JSON.generate(request_data)
  	$evm.log(:info,  "Adding Public DNS Record #{json_data} to CloudFlare Service ...")
  	response = cfdns.add_cloudflare_record(json_data)

  	result = response['success']

  	if result
      	$evm.log(:info, "Added DNS Public record successfully to CloudFlare DNS Service for instance [#{aws_instance}]")
  	else
   		$evm.log(:info, "Could not add Public DNS record successfully to CloudFlare DNS Service for instance [#{aws_instance}]")
  	end
  end
  
  # Check Private IP address second ...
  unless private_ip_address.nil?
   # Let's create the public DNS record ...
   # Create the Add DNS Record request.
   # Add a DNS Record to CloudFlare Data we will be adding

    request_data = {}
  	request_data[:type] = "A"
  	request_data[:name] = dns_name + "-int." + dns_domain
    request_data[:content] = private_ip_address
  	request_data[:ttl] = "120"
  
  	json_data = JSON.generate(request_data)
    $evm.log(:info,  "Adding Private DNS Record #{json_data} to CloudFlare Service ...")
  	response = cfdns.add_cloudflare_record(json_data)

  	result = response['success']

  	if result
      $evm.log(:info, "Added DNS Private record successfully to CloudFlare DNS Service for instance [#{aws_instance}]")
  	else
      $evm.log(:info, "Could not add Private DNS record successfully to CloudFlare DNS Service for instance [#{aws_instance}]")
  	end
  end
  
  
  exit MIQ_OK
    
rescue => ex
    $evm.log(:info, "register_amazon_vm: EXCEPTION #{ex.message}")
    exit MIQ_ABORT
end
