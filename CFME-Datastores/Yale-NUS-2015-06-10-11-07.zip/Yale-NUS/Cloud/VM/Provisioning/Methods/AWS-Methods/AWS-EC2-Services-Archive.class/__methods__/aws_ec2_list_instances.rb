#
#            Automate Method
#
$evm.log("info", "Automate Method Started")
#
#            Method Code Goes here
#

instances_box = $evm.root['dialog_aws_instances']

$evm.log("info", "===========================================")
  $evm.log("info", "Listing ROOT Attributes:")
  $evm.root.attributes.sort.each { |k, v| $evm.log("info", "\t#{k}: #{v}")}
  $evm.log("info", "===========================================")

$evm.log("info", "===========================================")
  $evm.log("info", "Listing OBJECT Attributes:")
  $evm.object.attributes.sort.each { |k, v| $evm.log("info", "\t#{k}: #{v}")}
  $evm.log("info", "===========================================")
exit MIQ_OK
