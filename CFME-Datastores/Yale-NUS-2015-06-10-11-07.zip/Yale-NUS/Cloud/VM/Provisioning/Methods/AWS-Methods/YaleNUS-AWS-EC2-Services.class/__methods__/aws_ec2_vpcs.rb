#            Automate Method
#
$evm.log("info", "====== RETRIEVE AMAZON VPCs ===== Automate Method Started")
#
#            Method Code Goes here
#
# Method for logging
def log(level, message)
  @method = 'create_attach_ebs_volume_button'
  $evm.log(level, "#{@method} - #{message}")
end
#

# Load the aws-sdk
require "aws-sdk"

begin
  dialog_field = $evm.object
  access_key_id = nil
  secret_access_key = nil

  # Get the Amazon authentication credentials...
  ems = $evm.vmdb(:ems_amazon).first
  
  if ems.nil?
    # Get the values from the schema ...
    access_key_id ||= $evm.object['access_key_id']
    secret_access_key = $evm.object.decrypt('secret_access_key')
  else
    access_key_id ||= ems.authentication_userid
    secret_access_key = ems.authentication_password
  end
  
  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  selected_region = $evm.object['dialog_aws_region']
  log(:info, "++++++++++++++++++++++++ Region : #{selected_region} +++++++++++++++++++++++++++++++")


  if selected_region == nil
    default_region = $evm.object['dialog_aws_region']
  else
    default_region = selected_region
  end

  # Create the basic EC2 object
  ec2_instance = AWS::EC2.new(:region => default_region)

  # Retrieve the available EC2 Regions
  vpcs = ec2_instance.vpcs

  # Create some local variables ...

  # Dynamic list to add values to the dialog dynamic list ...
  list = {}

  # Count of regions ...
  count = 0

  # Save first entry and make it the default region
  first = nil

  # Go through all vpcs returned from EC2 and add them to list
  vpcs.each do |k|
    count += 1
    if count == 1
      first = k.id
    end
    $evm.log("info", "VPC Name: #{k.id} ")
    list[k.id]  = "#{k.id}|#{k.cidr_block}"
  end

  list[""] = ""

  $evm.log("info", "LIST: #{list.inspect} ")

  # Add list to dialog dynamic list ...
  $evm.object["values"] = list

  # Make the first entry the default value
  dialog_field["default_value"] = first
  $evm.log("info", "====== RETRIEVE AMAZON VPCs =====  Automate Method Ended")
  exit MIQ_OK

rescue => exception
  $evm.log("info", "====== EXCEPTION IN RETRIEVE AMAZON VPCs =====")
  $evm.log("info", exception.message)
end
