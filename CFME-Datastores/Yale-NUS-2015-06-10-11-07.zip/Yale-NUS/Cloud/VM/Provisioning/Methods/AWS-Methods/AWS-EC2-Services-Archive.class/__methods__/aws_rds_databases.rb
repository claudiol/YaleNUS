#
#            Automate Method
#
$evm.log("info", "AWS DB List - Automate Method Started")
#
#            Method Code Goes here
#
#
# This is a static list but at least any dialog that needs it can get it from here
# AND there's only one place to change it in the future.
#

aws_db_list = [ "MySQL",
         "postgres",
         "oracle-se1",
         "oracle-se",
         "oracle-ee",
         "sqlserver-ee",
         "sqlserver-se",
         "sqlserver-ex",
         "sqlserver-web"
       ]

begin
   $evm.log("info", "LIST: #{list.inspect} ")

   # Add list to dialog dynamic list ...
   $evm.object["values"] = aws_db_list

   # Make the first entry the default value
   dialog_field["default_value"] = first
   exit MIQ_OK

rescue => exception
   $evm.log("info", "====== EXCEPTION IN RETRIEVE AMAZON VPCs =====")
   $evm.log("info", exception.message)
end
