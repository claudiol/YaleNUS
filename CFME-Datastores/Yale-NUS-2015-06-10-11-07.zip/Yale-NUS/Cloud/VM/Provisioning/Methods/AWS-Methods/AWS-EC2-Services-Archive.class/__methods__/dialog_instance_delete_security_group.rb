###################################
#
# CloudForms Automate Method: Dialog_Instance_Delete_Security_Group
#
# This method is used to populate all existing security groups for the dynamic drop down list
#
###################################
#
# Method for logging
begin
  @method = 'Dialog_Instance_Delete_Security_Group'
  $evm.log("info", "#{@method} - EVM Automate Method Started")

  # Turn of verbose logging
  @debug = true

  ###################################
  # Method: dumpRoot
  #
  ###################################
  def dumpRoot
    $evm.log("info", "#{@method} - Root:<$evm.root> Begin Attributes")
    $evm.root.attributes.sort.each { |k, v| $evm.log("info", "#{@method} - Root:<$evm.root> Attributes - #{k}: #{v}")}
    $evm.log("info", "#{@method} - Root:<$evm.root> End Attributes")
    $evm.log("info", "")
  end

  dumpRoot

  ###################################
  # Method: dumpRoot
  #
  ###################################
  require 'aws-sdk'

  access_key_id = nil
  secret_access_key = nil

  # Get the Amazon authentication credentials...
  ems = $evm.vmdb(:ems_amazon).first
  
  if ems.nil?
    # Get the values from the schema ...
    access_key_id ||= $evm.object['access_key_id']
    secret_access_key = $evm.object.decrypt('secret_access_key')
  else
    access_key_id ||= ems.authentication_userid
    secret_access_key = ems.authentication_password
  end
  
  allowed_regions = $evm.object['allowed_regions']
  allowed_regions = allowed_regions.split(",").each {|t| t.strip!}
  vm = $evm.root['vm']
  instance_id = nil
  instance_id = vm['uid_ems']
  current_region = vm.ext_management_system['hostname']

  $evm.log("info", "#{@method} - ================================= EVM Automate Method Started")

  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  ec2 = AWS::EC2.new( :access_key_id => access_key_id,
                      :secret_access_key => secret_access_key,
                      :region => current_region)

  i = ec2.instances["#{instance_id}"]
  $evm.log("info", "#{@method} - ===================== task: #{i.inspect}")

  security_groups = i.security_groups
  $evm.log("info", "#{@method} - ===================== sg before: #{security_groups.inspect}")

  @list_array = Array.new

  $evm.log("info", "#{@method} - ===================== security_groups.count: #{security_groups.count.inspect}")

  if security_groups.count == 1
    $evm.log("info", "#{@method} - ===================== security_groups.count: #{security_groups.count.inspect}")
    default_val = ["You cannot delete any Security groups unless there are more than 1 security groups attached",nil]
    @list_array << default_val
  else
    default_val = [nil,nil]
    @list_array << default_val

    security_groups.each do |sg|
      $evm.log("info", "#{@method} - ================ security_groups: #{sg.inspect}")
      val = Array.new
      val << "#{sg.name} - #{sg.description}"
      val << sg.security_group_id
      @list_array << val
    end
  end

  list_values = {
      'sort_by' => :none,
      'data_type' => :integer,
      'required' => :true,
      'values' => @list_array
  }
  $evm.log("info", "===== EVM Automate Method: <#{@method}> display drop-down: #{list_values}")
  list_values.each {|k,v| $evm.object[k] = v }



  $evm.log("info", "#{@method} - ================================= EVM Automate Method Ended")

  #
  # Exit method
  #
  $evm.log("info", "#{@method} - EVM Automate Method Ended")
  exit MIQ_OK

    #
    # Set Ruby rescue behavior
    #
rescue => err
  $evm.log("error", "#{@method} - [#{err}]\n#{err.backtrace.join("\n")}")
  exit MIQ_STOP
end
