#
# Description: This method is used to process tasks immediately after the VM has been provisioned
#

# Get provisioning object
prov = $evm.root["miq_provision"]

######################
# MODIFY THIS LINE TO DEFINE WHICH FLOATING IP POOL IS USED BY DEFAULT TO ASSIGN IPS ON PROVISIONING.
######################
$evm.root["/Integration/OpenStack/Neutron/FloatingIPAttach/floating_pool_name"] = "public"

# Populate VM ID for floating IP allocation.
$evm.root["/Integration/OpenStack/Neutron/FloatingIPAttach/vm_id"] = prov.vm.id

$evm.log("info", "Provisioning ID:<#{prov.id}> Provision Request ID:<#{prov.miq_provision_request.id}> Provision Type: <#{prov.provision_type}>")
