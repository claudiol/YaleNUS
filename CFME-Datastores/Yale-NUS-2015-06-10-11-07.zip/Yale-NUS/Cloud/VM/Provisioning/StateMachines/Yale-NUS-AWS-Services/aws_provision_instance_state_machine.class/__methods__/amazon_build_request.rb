###################################
#
# CloudForms Automate Method: build_request_amazon
#
# This method is used to build provision request for Amazon
#
###################################
begin
  # Load the aws-sdk
  #gem 'aws-sdk','=1.50.0'
  require "aws-sdk"

  # Method for logging
  def log(level, message)
    @method = 'build_request_amazon'
    $evm.log(level, "#{@method} - #{message}")
  end
  log(:info, "<CloudForms Automate Method Started")
  
  
  # Start Here
  def build_request(template_options, vm_options, tag_options, ws_options)
    user = $evm.root['user']
    user_id = user ? user.userid : "admin"
    #user_email = user ? user.email : "lester@redhat.com" #"admin@example.com"
    user_email = "lester@redhat.com" #"admin@example.com"
    # Setup the parameter needed for request
    args = []
    # arg1 = version
    args << '1.1'
    # arg2 = templateFields
    args << template_options.collect { |k, v| "#{k}=#{v}" }.join('|')
    # arg3 = vmFields
    args << vm_options.collect { |k, v| "#{k}=#{v}" }.join('|')
    # arg4 = requester
    args << "user_name=#{user_id}|owner_email=#{user_email}"
    # arg5 = tags
    args << tag_options.collect { |k, v| "#{k}=#{v}" }.join('|')
    # arg6 = WS Values
    args << ws_options.collect { |k, v| "#{k}=#{v}" }.join('|')
    # arg7 = emsCustomAttributes
    args << nil
    # arg8 = miqCustomAttributes
    args << nil

    log(:info, "#{@method} - Building provisioning request with the following arguments: <#{args.inspect}>")
    $evm.execute('create_provision_request', *args)
  end
  
# Look in tags_hash for tags and tag the service
def tag_service(service, tags_hash)
  # Look for tags with a sequence_id of 0 to tag the destination Service
  unless tags_hash.nil?
    tags_hash.each do |k, v|
      $evm.log("info", "Adding Tag:<#{k.inspect}/#{v.inspect}> to Service:<#{service.name}>")
      service.tag_assign("#{k}/#{v}")
    end
  end
end

# name_service - name the service to avoid duplicate names
def name_service(service, new_service_name=nil)
  unless new_service_name.blank?
    log(:info, "Changing Service name:<#{service.name}> to <#{new_service_name}>")
  else
    new_service_name = "#{service.name}-#{Time.now.strftime('%Y%m%d-%H%M%S')}"
    log(:info, "Changing Service name:<#{service.name}> to <#{new_service_name}>")
  end
  service.name = new_service_name
end

  
# Start
# Set up the Service Task
log(:info, "===========================================")
log(:info, "#{@method} - Listing ROOT Attributes:")
$evm.root.attributes.sort.each { |k, v| log(:info, " \t#{k}: #{v}") }
 log(:info, "===========================================")

  
log(:info, "#{@method} - CloudForms Service Task starting")
stp_task = $evm.root["service_template_provision_task"]
  
# Get destination service object
service = stp_task.destination
$evm.log("info", "Detected Service:<#{service.name}> Id:<#{service.id}>")
  
  # Pull dialog data
  vm_name = $evm.root['dialog_instance_name'].to_s
  default_region = $evm.root['dialog_aws_region'].to_s
  ##route = $evm.root['dialog_route'].to_s
  ##log(:info, "Route setting: #{route}")
 
  access_key_id  = $evm.object.decrypt('access_key_id')
  secret_access_key  = $evm.object.decrypt('secret_access_key')
  if $evm.root['dialog_aws_region'] == "us-east-1"
    awszone= "east"
  else
    awszone = "west"
  end

  vpc = $evm.root['dialog_aws_vpc'].to_s
  subnet_id, subnet_icdr_block = $evm.root['dialog_aws_subnet_list'].split("|")
  availability_zone_dialog = $evm.root.attributes['dialog_aws_availability_zone'].to_s
  log(:info, "Availability Setting: #{availability_zone_dialog}")

  # Process tag dialogs

  # Pull dialog data
  project = JSON.parse($evm.root['dialog_project'])
  log(:info, "Project tag ID: #{ project['tag_id'] }")
  log(:info,"Project tag name: #{ project['tag_name'] }")
  project_tag = project['tag_id']

 
  # Tag the service
  log(:info, "Assigning #{project['tag_name']} to service")
  service.tag_assign(project['tag_name'])

  log(:info, "Got Keys")

  # Set amazon config
  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )
  # Create the basic EC2 object
  ec2 = AWS::EC2.new(:region => default_region)
  
  # Section to set provision options
  # Template options
  template_options = {}
  
  aws_ami_id, aws_region, aws_ami_name = $evm.root['dialog_aws_image'].split("|")
  
  
  aws_template_info = $evm.vmdb("miq_template").find_by_ems_ref(aws_ami_id)
  
  guid = aws_template_info['GUID']
  
  template_options[:guid] = guid
  template_options[:request_type] = 'template'

  # VM Fields
  vm_options = {}
  # Get the root password for the instance
  vm_options[:root_password] = $evm.root['dialog_root_password']
  vm_options[:name] = vm_name.downcase
  vm_options[:vm_name] = vm_name.downcase
  vm_options[:hostname] = vm_name.downcase
  vm_options[:number_of_vms] = $evm.root['dialog_num_instances'] 

  
  new_service_name = vm_name.downcase 
  name_service(service, new_service_name)
  

 # Tags
  tag_options = {}
  tag_options[:project] = project_tag
  tag_options[:data_class] = project['tag_name']
  tag_options[:vm_tags] = project['tag_name']

  # Get the customization template to pass in the SSH key and Password for the instance.
  customization_template = $evm.vmdb(:customization_template).find_by_description($evm.object['customization_template'])
  net_tags=nil
  
  # WS_Values
  #ws_options = {}
  # WS_Values - George Goh made me do it :-)
  ws_options = stp_task.options[:dialog].dup
  ws_options[:availability_zone] = availability_zone_dialog
  ws_options[:subnet] = subnet_id unless subnet_id.blank?
  ws_options[:subnet_name] = net_tags['Name'] unless net_tags.nil?
  ws_options[:region] = default_region
  ws_options[:image_id] = aws_ami_id
  ws_options[:vpc] = vpc unless vpc.nil?
  ws_options[:flavor] = $evm.root['dialog_aws_instance_type']
  ws_options[:aws_zone] = awszone

  ws_options[:project] = project_tag
  ws_options[:vm_tags] = [project['tag_id']]

  ws_options[:service_id] = "#{service.id}"
  
  retirement_date = $evm.root['dialog_retirement_date'];
  log(:info, "Retirement date: #{retirement_date}")
  
  # We will process this once the VM is provisioined. Code currently in AddVMToService method.
  ws_options[:retires_on] = retirement_date

  ws_options[:customization_template_id] = customization_template.id


# To support key pairs coming from Amazon ...
  #ws_options[:keypair_chosen] = $evm.root['dialog_aws_ssh_pair']
  #ws_options[:key_name] = $evm.root['dialog_aws_ssh_pair']

  # Build the request with all information
  build_request(template_options, vm_options, tag_options, ws_options)
  
  
  ############
  # Exit method
  #
  stp_task.finished("Service Task Finished")
  log(:info, "CloudForms Automate Method Ended")
  exit MIQ_OK

    #
    # Set Ruby rescue behavior
    #
rescue => err
  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")
  exit MIQ_ABORT
end


