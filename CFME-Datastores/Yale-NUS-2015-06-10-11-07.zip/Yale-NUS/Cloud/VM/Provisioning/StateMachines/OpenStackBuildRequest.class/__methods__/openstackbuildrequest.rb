###################################
#
# CloudForms Automate Method: build_request_openstack
#
# This method is used to build provision request for Openstack
#
# RedHat: George Goh (modified from original code from Bill Helgeson)
###################################
###### UTILITY METHODS ######
# Method for logging
def log(level, message)
  @method = 'build_request_openstack'
  $evm.log(level, "#{message}")
end

# Convenience methods
def info(message)
  log(:info, message)
end

def debug(message)
  log(:debug, message)
end

def dump_root
  info("Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| info(" Attribute - #{k}: #{v}") }
  info("Root:<$evm.root> Attributes - End")
  info("")
end

def dump_attributes(object)
  info("Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| info("  #{k} = #{v.inspect}") }
  info("End Attributes [object.attributes]")
  info("")
end
###### UTILITY METHODS ######

# Look in tags_hash for tags and tag the service
def tag_service(service, tags_hash)
  # Look for tags with a sequence_id of 0 to tag the destination Service
  unless tags_hash.nil?
    tags_hash.each do |k, v|
      $evm.log("info", "Adding Tag:<#{k.inspect}/#{v.inspect}> to Service:<#{service.name}>")
      service.tag_assign("#{k}/#{v}")
    end
  end
end


# name_service - name the service to avoid duplicate names
def name_service(service, new_service_name=nil)
  unless new_service_name.blank?
    log(:info, "Changing Service name:<#{service.name}> to <#{new_service_name}>")
  else
    new_service_name = "#{service.name}-#{Time.now.strftime('%Y%m%d-%H%M%S')}"
    log(:info, "Changing Service name:<#{service.name}> to <#{new_service_name}>")
  end
  service.name = new_service_name
end


begin
  info("<CloudForms Automate Method Started")

  # Start Here
  def build_request(template_options, vm_options, tag_options, ws_options)
    user = $evm.root['user']
    user_id = user ? user.userid : "admin"
    user_email = user ? user.email : "admin@example.com"

    # Setup the parameter needed for request
    args = []
    # arg1 = version
    args << '1.1'
    # arg2 = templateFields
    args << template_options.collect { |k, v| "#{k}=#{v}" }.join('|')
    # arg3 = vmFields
    args << vm_options.collect { |k, v| "#{k}=#{v}" }.join('|')
    # arg4 = requester
    args << "user_name=#{user_id}|owner_email=#{user_email}"
    # arg5 = tags
    args << tag_options.collect { |k, v| "#{k}=#{v}" }.join('|')
    # arg6 = WS Values
    args << ws_options.collect { |k, v| "#{k}=#{v}" }.join('|')
    # arg7 = emsCustomAttributes
    args << nil
    # arg8 = miqCustomAttributes
    args << nil

    info("ARGS: #{args}")
    info("Building provisioning request with the following arguments: <#{args.inspect}>")
    $evm.execute('create_provision_request', *args)
  end

  # check for tag by project create if does not exists
  def tag_exists(tag_name, category_name, desc)
    if $evm.execute('tag_exists?', category_name, tag_name)
      info("Tag <#{tag_name}> exists")
    else
      info("Adding new tag <#{tag_name}> in Category <#{category_name}>")
      $evm.execute('tag_create', category_name, :name => tag_name, :description => "#{desc}")
    end
  end

  # Start

  # Set up the Service Task
  info("CloudForms Service Task starting")
  stp_task = $evm.root["service_template_provision_task"]
  # Get destination service object
  service = stp_task.destination

  # Pull dialog data
  project = JSON.parse($evm.root['dialog_project'])
  info("Project tag ID: #{ project['tag_id'] }")
  info("Project tag name: #{ project['tag_name'] }")
  project_tag = project['tag_id']
  service_name = ($evm.root['dialog_service_name'].strip.gsub(/\W/, '_')).downcase
  vm_name = ($evm.root['dialog_vm_name'].strip.gsub(/\W/, '_')).downcase

  tag_exists(project['tag_name'],"projects",project['tag_name']) unless project.nil?

  # Section to set provision options
  
  # Name the service
  name_service(service, service_name)
  
  # Tag the service
  info("Assigning #{project['tag_name']} to service")
  service.tag_assign(project['tag_name'])
  
  # Template options
  template_options = {}
  image = $evm.vmdb(:template_cloud).find($evm.root['dialog_image'])
  template_options[:guid] = image.guid
  template_options[:ems_guid] = image.ems_ref_string
  template_options[:request_type] = 'template'

  # Get Ext Management System and placement info
  ems = $evm.vmdb(:ext_management_system).find(image.ems_id)
  placement_auto = $evm.object['placement_auto']
  unless placement_auto==true
    placement_availability_zone = ems.availability_zones.select { |az| az.ems_ref == $evm.object['placement_availability_zone'] }.first
    cloud_tenant = ems.cloud_tenants.select { |tenant| tenant.name == $evm.object['cloud_tenant'] }.first
    cloud_network = ems.cloud_networks.select { |network| network.name == $evm.object['cloud_network'] }.first
    customization_template = $evm.vmdb(:customization_template).find_by_description($evm.object['customization_template'])
  end
  
  # VM Fields
  vm_options = {}
  #vm_options[:pxe_image_id]      = pxe_image.id
  #vm_options[:pxe_server_id]     = pxe_image.pxe_server.id
  vm_options[:vm_name] = vm_name.downcase
  
  vm_options[:hostname] = vm_name.downcase
  vm_options[:root_password] = $evm.root['dialog_root_password']
  vm_options[:number_of_vms] = $evm.root['dialog_vm_qty']

  # Tags
  tag_options = {}
  tag_options[:project] = project_tag
  tag_options[:data_class] = project['tag_name']
  tag_options[:vm_tags] = project['tag_name']
  
  # WS_Values
  ws_options = stp_task.options[:dialog].dup
  info("WS options: #{ws_options.inspect}")
  ws_options[:project] = project_tag
  ws_options[:instance_type] = $evm.root['dialog_vm_size']
  ws_options[:vm_tags] = [project['tag_id']]

  # placement
  ws_options[:placement_auto] = placement_auto ? [true, 1] : [false, 0]
  unless placement_auto==true
    ws_options[:placement_availability_zone] = [placement_availability_zone.id, placement_availability_zone.name]
    ws_options[:cloud_tenant] = [cloud_tenant.id, cloud_tenant.name]
    ws_options[:cloud_network] = [cloud_network.id, cloud_network.name]
    ws_options[:security_groups] = [65000000000042]
    ws_options[:customization_template_id] = customization_template.id
  end

  # associate VM with service
  ws_options[:service_id] = "#{service.id}"

  # Build the request with all information
  build_request(template_options, vm_options, tag_options, ws_options)
  ############
  # Exit method
  #
  stp_task.finished("Service Task Finished")
  info("CloudForms Automate Method Ended")
  exit MIQ_OK

    #
    # Set Ruby rescue behavior
    #
rescue => err
  log(:error, "[#{err}]\n#{err.backtrace.join("\n")}")
  exit MIQ_ABORT
end
