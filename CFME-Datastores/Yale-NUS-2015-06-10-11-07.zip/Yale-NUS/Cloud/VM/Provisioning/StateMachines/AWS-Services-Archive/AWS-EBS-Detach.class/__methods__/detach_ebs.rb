###################################
#
# CloudForms Automate Method: detach_ebs
#
# This method is used to detach a AWS EC2 EBS Volume from an instance
#
###################################
# Method for logging
def log(level, message)
  @method = 'detach_ebs'
  $evm.log(level, "#{@method} - #{message}")
end

def dumpRoot
  $evm.log("info", "#{@method} - Root:<$evm.root> Begin Attributes")
  $evm.root.attributes.sort.each { |k, v| $evm.log("info", "#{@method} - Root:<$evm.root> Attributes - #{k}: #{v}")}
  $evm.log("info", "#{@method} - Root:<$evm.root> End Attributes")
  $evm.log("info", "")
end

# dump root object attributes
dumpRoot

log(:info, "CloudForms Automate Method Started")

require 'aws-sdk'
dialog_field = $evm.object

# Get provisioning object

begin
  vm = $evm.root['vm']
  #log(:info, " VM Info : #{vm.inspect}")

  ems = vm.ext_management_system

  region = ems.provider_region

  # Get the Amazon authentication credentials...
  access_key_id ||= ems.authentication_userid
  secret_access_key = ems.authentication_password

  AWS.config(
      :access_key_id => access_key_id,
      :secret_access_key => secret_access_key
  )

  # Start Here
  log(:info, " ++++++++++++++++++ Selected Region: #{region} ++++++++++++++++++++")

  #
  ec2 = AWS::EC2.new( :region => region )

  selected_ebs_volume = $evm.root.attributes['dialog_aws_ec2_ebs_list_attachments']
  log(:info, "++++++++++++ Selected EBS Volume : #{selected_ebs_volume} ++++++++++++++++++++")

  volume_id, device, name = selected_ebs_volume.split('|')

  # Start Here
  volume = ec2.volumes[volume_id]
  log(:info, "+++++++++++++++++ Inspect Volume : #{volume.inspect} +++++++++++++++++++++++++")
  volume.attachments.each do |attachment|
    attachment.delete(:force => true)
  end
  sleep 1 until volume.status == :available

  # Email info

  vars = Hash.new
  vars[:type] = "detach_ebs_volume"
  vars[:action] = "Detached"
  vars[:service_name] = "AWS EBS"
  vars[:vol_name] = selected_ebs_volume
  vars[:vm_name] = vm['name']

  require 'json'
  require 'uri'
  args = "payload=#{vars.to_json}"
  args = URI.escape(args)
  $evm.log("info", "============== vars: #{vars.inspect}")
  $evm.log("info", "============== args: #{args.inspect}")
  $evm.instantiate("/Yale/Methods/Emails/Email_Owner?#{args}")

  ############
  # Exit method
  #
  log(:info, "Detach EBS Volume - CloudForms Automate Method Ended")
  exit MIQ_OK
end
