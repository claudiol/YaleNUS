#            Automate Method
#
$evm.log("info", "======== CREATE S3 BUCKET ======== Automate Method Started")
#
#            Method Code Goes here
#
require 'aws-sdk'

begin
   access_key_id = nil
   secret_access_key = nil
 
# Get the Amazon authentication credentials...
   access_key_id ||= $evm.object['access_key_id']
   secret_access_key = $evm.object.decrypt('secret_access_key')
   AWS.config(
      :access_key_id => access_key_id,
  	:secret_access_key => secret_access_key
   )

   # Get the name of the bucket name from the request ... validate_bucket_name adds it
   bucket_name = $evm.root['bucket_name']
   # Retrieve the region from the dialog
   region      = $evm.root['bucket_aws_region']

   task = $evm.root["service_template_provision_task"]
   $evm.log("info", "#{task.inspect}")

   $evm.log("info", "========== AWS PROV ATTRIBUTE LOG =================================")
   $evm.log("info", "Listing ROOT Attributes:")
   $evm.root.attributes.sort.each { |k, v| $evm.log("info", "\t#{k}: #{v}")}
   $evm.log("info", "=========== AWS PROV ATTRIBUTE LOG ================================")


   $evm.log("info", "========== SERVICE TASK ATTRIBUTE LOG =================================")
   $evm.log("info", "Listing SERVICE TASK Attributes:")
   task.attributes.sort.each { |k, v| $evm.log("info", "\t#{k}: #{v}")}
   $evm.log("info", "=========== SERVICE TASK ATTRIBUTE LOG ================================")


   vm = $evm.root['vm']
   $evm.log("info", vm.inspect)

   # Create the basic S3 object
   s3_instance = AWS::S3.new(:region => region)

   # Load up the 'bucket' we want to store things in
   bucket = s3_instance.buckets[bucket_name]
   # If the bucket doesn't exist, create it
   begin
      unless bucket.exists?
	     $evm.log("info", "Creating AWS S3 bucket #{bucket_name}...")
		 s3_instance.buckets.create(bucket_name)
	     # Return the newly created bucket
	  else
		 $evm.log("info", "Bucket #{bucket_name} already exists! Aborting!")
	     exit MIQ_ABORT
	  end
   rescue => ex
        $evm.log("info", "======  AWS Exception =====")
        $evm.log("info", ex.message)
        exit MIQ_ABORT
   end
rescue => ex
     $evm.log("info", "======  AWS Exception =====")
     $evm.log("info", ex.message)
     exit MIQ_ABORT
end
#
#
#
$evm.log("info", "======== CREATE S3 BUCKET ======== Automate Method Ended")
exit MIQ_OK
