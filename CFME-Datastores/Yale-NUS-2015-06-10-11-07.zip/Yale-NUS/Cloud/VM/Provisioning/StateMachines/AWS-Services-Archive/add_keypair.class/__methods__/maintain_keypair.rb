###################################
#
# CloudForms Automate Method: maintain_keypair
#
# This method is used to maintain an AWS Keypair
#
###################################
# Method for logging
def log(level, message)
  @method = 'maintain_keypair'
  $evm.log(level, "#{@method} - #{message}")
end

log(:info, "@@@@@@@@@@@@@@ CloudForms Automate Method Started @@@@@@@@@@@@@@")

require 'aws-sdk'



begin
  delete_only = false
  delete_only = $evm.object['delete_only'] #from schema
  ssh_key = $evm.object['dialog_ssh_key']
  verbose_logging = false


  # Get the Amazon authentication credentials...
  access_key_id = nil
  secret_access_key = nil

  access_key_id = $evm.object['access_key_id']
  secret_access_key = $evm.object.decrypt('secret_access_key')

  #get username and group name cleaned up
  this_user = $evm.root['user'].userid.downcase
  log(:info, "this_user : #{this_user.inspect}")
  this_user_group = $evm.root['user'].miq_group.description.downcase.gsub(/[\W+]|[_]/,'') #AWS doesn't like underscores, dashes or spaces so strip
  log(:info, "this_user_group (cleaned of underscores): #{this_user_group.inspect}")

  keypair_name = "#{this_user_group}_#{this_user}"
  log(:info, "The calculated name of the keypair will be: #{keypair_name}")

  if this_user.nil? || this_user_group.nil?
    exit MIQ_ABORT
  end

  log(:info, '==============Keypair process started=================')
  allowed_regions = $evm.object['allowed_regions']
  allowed_regions = allowed_regions.split(',').map(&:strip) #get into array, cleanup spaces

  if allowed_regions.nil?
    exit MIQ_ABORT
  end

  allowed_regions.each do |r|

    log(:info, "<<<<<<<<<================>>>>>>>>> Processing region #{r}  <<<<<<<<<<<<<=================>>>>>>>>>>>>>")

    log(:info, '   ================ Creating EC2 object =================')
    ec2 = AWS::EC2.new( :access_key_id => access_key_id,
                        :secret_access_key => secret_access_key,
                        :region => r)

    ec2.key_pairs.each do |kp|
      log(:info,"#{kp.inspect}") if verbose_logging

      if kp.name == keypair_name
        kp.delete
        log(:info, "     !!!!!!!!!found and deleted #{keypair_name}!!!!!!!!!!!!!!!")
      end
    end

    unless delete_only
      log(:info, "   =========Now uploading keypair_name: #{keypair_name} ===========")

      ec2.key_pairs.import(keypair_name, ssh_key)
      log(:info, "   ********** keypair_name: #{keypair_name} uploaded **********")
      log(:info, '   ================ upload completed =================')

      #refersh EMS so keys show up faster
      $evm.vmdb('ext_management_system').all.each  {|e| e.refresh if e.type == 'EmsAmazon' }

    end

    if verbose_logging
      log(:info,'     ================ Now print out the keypairs =================')
      ec2.key_pairs.each do |kp|
        log(:info, kp.inspect)
      end
    end

    log(:info, "<<<<<<<<<================>>>>>>>>> Finished processing region #{r}  <<<<<<<<<<<<<=================>>>>>>>>>>>>>")

  end
  log(:info, "================ Complete!! =================")


  ############
  # Exit method
  #
  log(:info, "@@@@@@@@@@@@@@ CloudForms Automate Method Completed @@@@@@@@@@@@@@")
  exit MIQ_OK
end
