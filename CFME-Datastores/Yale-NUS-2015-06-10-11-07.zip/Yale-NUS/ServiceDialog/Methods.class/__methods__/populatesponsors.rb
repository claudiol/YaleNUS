#
# Description: Populate a dynamic drop down list with sponsors
#

###### TRACERS ######
# Method for logging
def log(level, message)
  @method = 'populateSponsors'
  $evm.log(level, "#{@method} - #{message}")
end

def info(message)
  log(:info, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

info("Automate Method Started")

require 'json'

cfuser = $evm.root["user"]
info("User id: #{$evm.root["user"][:userid]}")

droplist = $evm.object

droplist["data_type"] = "String"
droplist["required"] = "true"

sponsor_tag = 'yalenusattr/sponsor'
sponsors = $evm.vmdb('user').all.select { |u| u.tags.include? sponsor_tag }

if sponsors.empty?
  droplist["values"] = { "nil" => "No Sponsors" }
  exit MIQ_ABORT  
end


# create droplist values
option_hash = {}
sponsors.each { |sponsor|
  key = sponsor.id
  value = sponsor.name
  info("Adding '#{ key }':'#{ value }' to droplist values")
  option_hash[key] = value
}

info("Generated droplist options: #{ option_hash }")
droplist["values"] = option_hash

droplist["default_value"] = option_hash.keys[-1]

info("Automate Method Ended")

exit MIQ_OK
