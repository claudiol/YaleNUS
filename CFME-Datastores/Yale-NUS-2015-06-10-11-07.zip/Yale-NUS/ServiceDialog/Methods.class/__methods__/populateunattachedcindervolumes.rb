###################################
#
# CloudForms Automate Method: populateUnAttachedCinderVolumes
#
# This method is used to populate a drop-down list with a list of volumes 
# currently unattached to any OpenStack Instance
#
###################################

###### TRACERS ######
# Method for logging
def log(level, message)
  $evm.log(level, "#{message}")
end

def info(message)
  log(:info, message)
end

def error(message)
  log(:error, message)
end

def debug(message)
  log(:debug, message)
end

def dump_root
  log(:info, "Root:<$evm.root> Attributes - Begin")
  $evm.root.attributes.sort.each { |k, v| log(:info, "  Attribute - #{k}: #{v}") }
  log(:info, "Root:<$evm.root> Attributes - End")
  log(:info, "")
end

def dump_attributes(object)
  log(:info, "CUSTOM  Begin Attributes [object.attributes]")
  object.attributes.sort.each { |k, v| log(:info, "CUSTOM    #{k} = #{v.inspect}") }
  log(:info, "CUSTOM  End Attributes [object.attributes]")
  log(:info, "")
end
###### TRACERS ######

begin
  
  require 'fog'

  info("Automate method started.")
  
  vm = $evm.root['vm']
  if vm.nil?
    info("Not in VM context. Look for EMS ID in dialog.")
    # if the dialog doesn't specify an EMS id, then we assume the first OpenStack EMS.
    if $evm.object.attributes.key? 'dialog_ems_id'
      info("Dialog has ems_id")
      ems = $evm.vmdb(:ems_openstack).find($evm.object['dialog_ems_id'])
    else
      info("No EMS found, just going for the first one.")
      ems = $evm.vmdb(:ems_openstack).first
    end
  else
    info("VM name: #{ vm.name }")
    ems = vm.ext_management_system
  end
  info("EMS name: #{ ems.name }")

  # get tenant
  if vm.nil?
    if $evm.object.attributes.key? 'dialog_tenant'
      os_tenant = $evm.object['dialog_tenant']
    else
      os_tenant = $evm.object['tenant']
    end
  else
    os_tenant = ems.cloud_tenants.select { |t| t.id == vm.cloud_tenant_id }.first.name
  end
  
  # Set up Fog connection to Openstack.
  os_user_id = ems.authentication_userid
  os_password = ems.authentication_password
  os_auth_url = "http://#{ ems.hostname }:#{ ems.port }/v2.0/tokens"
  info("Fog provider: #{ ems.emstype }, openstack_username: #{ os_user_id }, openstack_api_key: #{ os_password }, openstack_auth_url: #{ os_auth_url }, openstack_tenant: #{ os_tenant }")
  
  fog_conn = Fog::Compute.new({:provider => ems.emstype,
                              :openstack_username => os_user_id,
                              :openstack_api_key => os_password,
                              :openstack_auth_url => os_auth_url,
                              :openstack_tenant => os_tenant})
  
  available_volumes = fog_conn.volumes.select { |v| v.status == 'available' }
  
  option_hash = {}
  available_volumes.each { |volume|
    key = volume.id
    value = volume.name
    debug("Adding '#{ key }:#{ value }' to droplist values")
    option_hash[key] = value
  }
  
  info("Generated droplist options: #{ option_hash }")

  droplist = $evm.object
  droplist["data_type"] = "String"
  droplist["required"] = "true"
  droplist["values"] = option_hash
  
  info("Automate method ended.")

  exit MIQ_OK
end
